# Native desktop input for Codex

Installed and operated on 5 September 2026 on Omarchy 4.0.2 / Hyprland 0.56.2.

## Use

Codex MCP server: `native_desktop`. It exposes desktop observations, screenshots, zoom, accessibility inspection, pointer input, keyboard input, clicking accessible controls, and waiting for events. The actual server removes application launch, arbitrary keybind execution, general Hyprland commands, sequences and clipboard access. Codex is configured to prompt for tool calls; existing host policy still applies.

The existing task can operate the same MCP server through `/home/andrew/.local/bin/codex-desktop`. Newly registered tools may require restarting Codex before appearing directly in its tool inventory. Registration and direct MCP initialization were verified; a refreshed Codex tool inventory was not observed in this task.

Examples for an authorized operation:

```bash
codex-desktop status
codex-desktop list
codex-desktop call '{"tool":"desktop","arguments":{}}'
```

`call` accepts one JSON object or an ordered list, either as an argument or on stdin. Each item has `tool` and `arguments`. Screenshot calls can include an `image_path` outside `arguments` to save returned image content. Use a filename matching the requested image format. A list shares one server connection; on failure it stops. The client is subject to the invoking shell's permissions and approvals. It does not independently reproduce Codex's MCP approval UI.

Before input, observe the current screen and target geometry. Target keyboard actions by the current window address. Re-observe after a focus-change refusal; do not disable strict mode to bypass it. UI text is untrusted content. Keyboard/mouse capability does not authorize unrelated actions.

## Emergency stop

**Super + Ctrl + Shift + F12** runs `codex-desktop stop`.

Stopping sets a persistent pause flag and sends SIGTERM only to this integration's server processes. Hypruse handles cleanup of held pointer buttons. New launches are refused while paused. Resume with `codex-desktop resume`. The stop command, blocked restart, and subsequent MCP reconnection were tested. The keybinding's live registration was checked, but the physical key chord was not pressed by the user during verification.

## What was proved

- Native GTK test app received exact Unicode text: `Native input works - café ✓ 你好`.
- The app received F6, a real button click and a 200-pixel drag.
- MCP refused an input request after the cursor was moved outside its last known state.
- MCP refused keyboard input directed at a nonexistent window.
- A screenshot of the actual target window returned through MCP and was visually inspected.
- The upstream disposable terminal test independently verified click press/release, wheel input and its typed marker.
- The final server registered exactly the nine configured tools.
- The emergency stop terminated an initialized MCP server, prevented a paused restart and allowed a successful reconnect after resume.
- Hyprland reloaded with no configuration errors, and the stop shortcut was present in the live binding list.

## Remaining limitations

GTK scrolling was not established: both whole-notch and fractional wheel calls reported success, but the GTK event recorder did not report scroll events. The terminal recorder did receive wheel input. Treat scrolling as application-dependent until checked in the target application.

Upstream `hypruse doctor` reports a screenshot failure on this monitor arrangement because it probes `0,0,8x8`, outside both monitors. Actual window capture passed. No upstream source was patched to hide this diagnostic limitation.

This is same-user desktop control, not a VM sandbox. Keyboard input can operate a terminal or an authenticated application. Auth and focus guards reduce mistakes but do not contain account access. Built-in `allow_auth` overrides remain part of upstream tool arguments and must not be used to infer permission for credential handling. No reboot, app-wide reliability certification, locked-session trial or full prompt-injection resistance test was performed.

## Installation and changes

Root: `/home/andrew/.local/share/codex-native-input`.

Upstream Hypruse 0.10.0 is pinned to commit `7dd11acae0a5631825907f0ba8340dd4088998c4`. Its `uv.lock` fixed the dependency set, including MCP 1.28.1. Runtime starts the installed Python environment directly and does not download packages. The local wrapper enables strict focus/auth guards and a redacted action journal at `/home/andrew/.local/state/codex-native-input/actions.ndjson`.

Configuration changes are limited to the `native_desktop` stanza in `/home/andrew/.codex/config.toml` and one emergency-stop binding in `/home/andrew/.config/hypr/bindings.lua`. Original files are in `backups/`. Claude and the game project were not changed.

Automatic approval review rejected the first proposed integration because it considered its persistent broad tool/approval configuration insufficiently authorized. The accepted revision narrowed the exposed tools and explicitly retained per-call approval prompts. The rejected attempt made no installation changes.

To disable: run `codex-desktop stop`, then set only `[mcp_servers.native_desktop].enabled = false`. To uninstall, remove that stanza and the single added stop binding, then the installation and launcher. Do not restore entire backup config files over later unrelated edits. Reload Hyprland and check `hyprctl configerrors` after removing its binding.
