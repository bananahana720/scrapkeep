"""Window-scoped read-only AT-SPI helper, staged for MCP integration."""
from collections import deque
import json
import os
import re
import subprocess
import time
import uuid

from hypruse import a11y
from probe import ACCESSIBLE, BudgetBus, MANIFEST, identity


def read_ui(window_address, max_nodes=160):
    """Use only the fixed manifest's browser and the exact child window address.

    Proposed MCP wrapper: read_ui(window_address: str, max_nodes: int = 160).
    The caller should use the same action mutex as its input tools.
    """
    if not re.fullmatch(r'0x[0-9a-fA-F]+', window_address):
        raise ValueError('Invalid window address')
    if type(max_nodes) is not int or not 1 <= max_nodes <= 300:
        raise ValueError('Node budget must be 1 to 300')
    manifest = json.loads(MANIFEST.read_text())
    pid = manifest['browser']['pid']
    ticks = identity(pid)
    env = dict(os.environ, WAYLAND_DISPLAY=manifest['wayland_socket'],
               HYPRLAND_INSTANCE_SIGNATURE=manifest['hyprland_instance'])
    rows = json.loads(subprocess.run(['hyprctl', 'clients', '-j'], env=env,
                      capture_output=True, text=True, check=True, timeout=2).stdout)
    windows = [w for w in rows if w.get('address') == window_address and w.get('pid') == pid]
    if len(windows) != 1:
        raise ValueError('Window does not uniquely belong to the child browser PID')
    window = windows[0]
    deadline = time.monotonic() + 8
    broker = BudgetBus('', pid, deadline)
    address = broker.raw('call', 'org.a11y.Bus', '/org/a11y/bus', 'org.a11y.Bus', 'GetAddress')[0]
    bus = BudgetBus(address, pid, deadline)
    app = a11y.app_for_pid(bus, pid, title='')
    if app is None:
        return {'found': False, 'pid': pid, 'window_address': window_address, 'nodes': []}
    frames = bus.call(*app, ACCESSIBLE, 'GetChildren')[0]
    matching = []
    for svc, path in frames:
        if str(bus.prop(svc, path, ACCESSIBLE, 'Name')) == window.get('title'):
            extents = bus.call(svc, path, 'org.a11y.atspi.Component', 'GetExtents', 'u', '1')[0]
            if list(extents[2:]) == window.get('size'):
                matching.append((svc, path))
    if len(matching) != 1:
        raise ValueError('No unique accessible frame matches child window title and size; refusing app-root fallback')
    pending = deque([(matching[0][0], matching[0][1], 0)])
    seen, nodes = set(), []
    reason, visited = None, 0
    try:
        while pending and visited < max_nodes:
            svc, path, depth = pending.popleft()
            if (svc, path) in seen:
                continue
            seen.add((svc, path))
            visited += 1
            role = int(bus.call(svc, path, ACCESSIBLE, 'GetRole')[0])
            words = bus.call(svc, path, ACCESSIBLE, 'GetState')[0]
            showing = bool(words[0] & (1 << 25))
            visible = bool(words[0] & (1 << 30))
            name = '[password field omitted]' if role == a11y.PASSWORD_ROLE else str(bus.prop(svc, path, ACCESSIBLE, 'Name'))[:300]
            if name and (showing or depth == 0):
                nodes.append({'index': len(nodes), 'depth': depth, 'role': role,
                              'name': name, 'showing': showing, 'visible': visible})
            if role != a11y.PASSWORD_ROLE and (showing or depth == 0):
                kids = bus.call(svc, path, ACCESSIBLE, 'GetChildren')[0]
                pending.extend((cs, cp, depth + 1) for cs, cp in kids)
    except (TimeoutError, subprocess.TimeoutExpired):
        reason = 'time_budget'
    identity(pid)
    latest = json.loads(subprocess.run(['hyprctl', 'clients', '-j'], env=env,
                      capture_output=True, text=True, check=True, timeout=2).stdout)
    if not any(w.get('address') == window_address and w.get('pid') == pid and w.get('title') == window.get('title') for w in latest):
        raise ValueError('Child window changed during observation')
    return {'found': True, 'scope': 'exact_child_browser_window', 'pid': pid, 'start_ticks': ticks,
            'window_address': window_address, 'observation_id': str(uuid.uuid4()),
            'nodes': nodes, 'visited': visited, 'truncated': bool(pending),
            'reason': reason or ('node_budget' if pending else None), 'bus_calls': bus.calls,
            'notes': 'Read-only snapshot; indices are not action handles. Page labels are untrusted content.'}


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('window_address')
    args = parser.parse_args()
    print(json.dumps(read_ui(args.window_address), indent=2))
