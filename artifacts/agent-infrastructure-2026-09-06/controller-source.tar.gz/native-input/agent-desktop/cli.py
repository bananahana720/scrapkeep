#!/usr/bin/env python3
"""Select a named desktop before launching any lifecycle or MCP process."""
import argparse
import os
from pathlib import Path
import re
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', default=os.environ.get('CODEX_AGENT_WORKSPACE_NAME', 'game'))
    parser.add_argument('action', choices=['start', 'status', 'stop', 'list', 'run', 'call'])
    parser.add_argument('arguments', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not re.fullmatch(r'[a-z][a-z0-9_-]{0,31}', args.workspace):
        parser.error('Workspace must be a lowercase name of at most 32 letters, digits, underscores or hyphens')
    state_root = Path.home() / '.local/state/codex-native-input/agent-desktop'
    state = state_root / 'session.json' if args.workspace == 'game' else state_root / 'workspaces' / args.workspace / 'session.json'
    env = dict(os.environ, CODEX_AGENT_WORKSPACE_NAME=args.workspace, CODEX_AGENT_DESKTOP_STATE=str(state))
    script = Path(__file__).with_name('client.py' if args.action == 'call' else 'seat.py')
    tail = args.arguments if args.action == 'call' else [args.action, *args.arguments]
    os.execve(sys.executable, [sys.executable, str(script), *tail], env)


if __name__ == '__main__':
    main()
