"""One-shot CLI client; the registered MCP server keeps a persistent connection."""
import asyncio
import base64
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    if len(sys.argv) < 2:
        raise SystemExit('Usage: codex-agent-desktop [--workspace NAME] call TOOL [JSON] [IMAGE_PATH]')
    name = sys.argv[1]
    arguments = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    token = os.environ.get('CODEX_AGENT_LEASE_TOKEN')
    if token and name != 'status':
        arguments.setdefault('lease_token', token)
    params = StdioServerParameters(command=sys.executable, args=[str(Path(__file__).with_name('server.py'))], env=dict(os.environ))
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(name, arguments)
            for block in result.content:
                if block.type == 'image':
                    if len(sys.argv) <= 3:
                        raise ValueError('Provide an absolute image output path for screenshot')
                    path = Path(sys.argv[3]).absolute()
                    path.write_bytes(base64.b64decode(block.data))
                    print(json.dumps({'image': str(path)}))
                elif block.type == 'text':
                    print(block.text)
            return bool(result.isError)


if __name__ == '__main__':
    raise SystemExit(1 if asyncio.run(main()) else 0)
