#include <gtk/gtk.h>
static int clicks;
static gboolean held[512];
static GtkLabel *key_state;
static GtkLabel *button_state;
static int buttons, button_events;
static gboolean pointer_event(GtkEventControllerLegacy *controller,GdkEvent *event,gpointer data) {
 GdkEventType type=gdk_event_get_event_type(event);
 if(type==GDK_BUTTON_PRESS) { buttons++; button_events++; }
 if(type==GDK_BUTTON_RELEASE) { buttons--; button_events++; }
 char text[96];g_snprintf(text,sizeof text,"held buttons: %d; button events: %d",buttons,button_events);gtk_label_set_text(button_state,text);return FALSE;
}
static void update_keys(void) { int count=0; for(int i=0;i<512;i++) count+=held[i]; char text[64]; g_snprintf(text,sizeof text,"held keys: %d",count); gtk_label_set_text(key_state,text); }
static gboolean key_pressed(GtkEventControllerKey *controller,guint keyval,guint keycode,GdkModifierType state,gpointer data) { if(keycode<512) held[keycode]=TRUE; update_keys(); return FALSE; }
static void key_released(GtkEventControllerKey *controller,guint keyval,guint keycode,GdkModifierType state,gpointer data) { if(keycode<512) held[keycode]=FALSE; update_keys(); }

static void clicked(GtkButton *button, GtkLabel *label) { char text[64]; g_snprintf(text,sizeof text,"clicks: %d",++clicks); gtk_label_set_text(label,text); }
int main(int argc,char **argv) {
 gtk_init(); GtkWidget *window=gtk_window_new(); gtk_window_set_title(GTK_WINDOW(window),"Agent stop verification"); gtk_window_set_default_size(GTK_WINDOW(window),700,400);
 GtkWidget *box=gtk_box_new(GTK_ORIENTATION_VERTICAL,20); gtk_widget_set_margin_top(box,30); gtk_widget_set_margin_start(box,30); gtk_widget_set_margin_end(box,30);
 gtk_window_set_child(GTK_WINDOW(window),box); gtk_box_append(GTK_BOX(box),gtk_label_new("Native background control test"));
 GtkWidget *entry=gtk_entry_new(); gtk_accessible_update_property(GTK_ACCESSIBLE(entry),GTK_ACCESSIBLE_PROPERTY_LABEL,"Test text",-1); gtk_box_append(GTK_BOX(box),entry);
 GtkWidget *button=gtk_button_new_with_label("Record click"),*label=gtk_label_new("clicks: 0"); gtk_box_append(GTK_BOX(box),button); gtk_box_append(GTK_BOX(box),label); g_signal_connect(button,"clicked",G_CALLBACK(clicked),label);
 key_state=GTK_LABEL(gtk_label_new("held keys: 0")); gtk_box_append(GTK_BOX(box),GTK_WIDGET(key_state));
 GtkEventController *keys=gtk_event_controller_key_new(); gtk_event_controller_set_propagation_phase(keys,GTK_PHASE_CAPTURE); g_signal_connect(keys,"key-pressed",G_CALLBACK(key_pressed),NULL); g_signal_connect(keys,"key-released",G_CALLBACK(key_released),NULL); gtk_widget_add_controller(window,keys);
 button_state=GTK_LABEL(gtk_label_new("held buttons: 0; button events: 0"));gtk_box_append(GTK_BOX(box),GTK_WIDGET(button_state));
 GtkEventController *pointer=gtk_event_controller_legacy_new();gtk_event_controller_set_propagation_phase(pointer,GTK_PHASE_CAPTURE);g_signal_connect(pointer,"event",G_CALLBACK(pointer_event),NULL);gtk_widget_add_controller(window,pointer);
 gtk_window_present(GTK_WINDOW(window)); GMainLoop *loop=g_main_loop_new(NULL,FALSE); g_main_loop_run(loop); return 0;
}
