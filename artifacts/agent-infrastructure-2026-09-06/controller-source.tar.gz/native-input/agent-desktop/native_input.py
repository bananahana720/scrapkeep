"""Physical input for one explicitly selected nested Hyprland session.

One caller owns this object and calls tick() at 50 Hz, including while waiting
for another command. Screenshot work must not block that caller.
"""
import base64
import ctypes
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import time

from hypruse.wire import (
    VirtualKeyboard, VirtualPointer, PRESSED, RELEASED, VK_KEY, VK_MODIFIERS, _now_ms, wl_string,
)

KEY_CODES = {
    "Escape": 1,
    "Digit1": 2, "Digit2": 3, "Digit3": 4, "Digit4": 5, "Digit5": 6,
    "Digit6": 7, "Digit7": 8, "Digit8": 9, "Digit9": 10, "Digit0": 11,
    "Minus": 12, "Equal": 13, "Backspace": 14, "Tab": 15,
    "KeyQ": 16, "KeyW": 17, "KeyE": 18, "KeyR": 19, "KeyT": 20,
    "KeyY": 21, "KeyU": 22, "KeyI": 23, "KeyO": 24, "KeyP": 25,
    "BracketLeft": 26, "BracketRight": 27, "Enter": 28, "ControlLeft": 29,
    "KeyA": 30, "KeyS": 31, "KeyD": 32, "KeyF": 33, "KeyG": 34,
    "KeyH": 35, "KeyJ": 36, "KeyK": 37, "KeyL": 38,
    "Semicolon": 39, "Quote": 40, "Backquote": 41, "ShiftLeft": 42,
    "Backslash": 43, "KeyZ": 44, "KeyX": 45, "KeyC": 46, "KeyV": 47,
    "KeyB": 48, "KeyN": 49, "KeyM": 50, "Comma": 51, "Period": 52,
    "Slash": 53, "ShiftRight": 54, "AltLeft": 56, "Space": 57, "CapsLock": 58,
    "F1": 59, "F2": 60, "F3": 61, "F4": 62, "F5": 63,
    "F6": 64, "F7": 65, "F8": 66, "F9": 67, "F10": 68,
    "NumLock": 69, "ScrollLock": 70, "F11": 87, "F12": 88,
    "ControlRight": 97, "PrintScreen": 99, "AltRight": 100,
    "Home": 102, "ArrowUp": 103, "PageUp": 104, "ArrowLeft": 105,
    "ArrowRight": 106, "End": 107, "ArrowDown": 108, "PageDown": 109,
    "Insert": 110, "Delete": 111, "Pause": 119,
    "MetaLeft": 125, "MetaRight": 126, "ContextMenu": 127,
}
ALIASES = {
    "esc": "Escape", "space": "Space", "Shift_L": "ShiftLeft",
    "Control_L": "ControlLeft",
    **{k[-1].lower(): k for k in KEY_CODES if k.startswith("Key")},
    **{k[-1]: k for k in KEY_CODES if k.startswith("Digit")},
    "enter": "Enter", "return": "Enter", "tab": "Tab", "backspace": "Backspace",
    "delete": "Delete", "insert": "Insert", "home": "Home", "end": "End",
    "up": "ArrowUp", "down": "ArrowDown", "left": "ArrowLeft", "right": "ArrowRight",
    "pageup": "PageUp", "pagedown": "PageDown",
    "Shift_R": "ShiftRight", "Control_R": "ControlRight",
    "Alt_L": "AltLeft", "Alt_R": "AltRight", "Super_L": "MetaLeft", "Super_R": "MetaRight",
    **{f"f{i}": f"F{i}" for i in range(1, 13)},
    "-": "Minus", "=": "Equal", "[": "BracketLeft", "]": "BracketRight",
    ";": "Semicolon", "'": "Quote", "`": "Backquote", "\\": "Backslash",
    ",": "Comma", ".": "Period", "/": "Slash",
}
MODIFIER_KEYS = frozenset({"ShiftLeft", "ShiftRight", "ControlLeft", "ControlRight",
                           "AltLeft", "AltRight", "MetaLeft", "MetaRight"})
KEYMAP = b'xkb_keymap { xkb_keycodes { include "evdev+aliases(qwerty)" }; xkb_types { include "complete" }; xkb_compatibility { include "complete" }; xkb_symbols { include "pc+us+inet(evdev)" }; };'


def _finite(value, name):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    return value


def _key_name(name):
    name = ALIASES.get(name, name)
    if name not in KEY_CODES:
        raise ValueError(f"Unsupported physical key: {name}")
    return name


class XkbState:
    """Aggregate modifier state for the exact keymap uploaded to Wayland."""

    def __init__(self, keymap):
        self.lib = ctypes.CDLL("libxkbcommon.so.0")
        pointer, uint = ctypes.c_void_p, ctypes.c_uint32
        signatures = {
            "xkb_context_new": ([ctypes.c_int], pointer),
            "xkb_context_unref": ([pointer], None),
            "xkb_keymap_new_from_string": ([pointer, ctypes.c_char_p, ctypes.c_int, ctypes.c_int], pointer),
            "xkb_keymap_get_as_string": ([pointer, ctypes.c_int], pointer),
            "xkb_keymap_unref": ([pointer], None),
            "xkb_state_new": ([pointer], pointer),
            "xkb_state_unref": ([pointer], None),
            "xkb_state_update_key": ([pointer, uint, ctypes.c_int], uint),
            "xkb_state_serialize_mods": ([pointer, ctypes.c_int], uint),
            "xkb_state_serialize_layout": ([pointer, ctypes.c_int], uint),
        }
        for name, (args, result) in signatures.items():
            function = getattr(self.lib, name)
            function.argtypes, function.restype = args, result
        self.context = self.keymap = self.state = None
        self.down = set()
        try:
            self.context = self.lib.xkb_context_new(0)
            if not self.context:
                raise RuntimeError("Could not create XKB context")
            self.keymap = self.lib.xkb_keymap_new_from_string(self.context, keymap, 1, 0)
            if not self.keymap:
                raise RuntimeError("Could not compile the physical keyboard map")
            self.state = self.lib.xkb_state_new(self.keymap)
            if not self.state:
                raise RuntimeError("Could not create aggregate keyboard state")
            serialized = self.lib.xkb_keymap_get_as_string(self.keymap, 1)
            if not serialized:
                raise RuntimeError("Could not serialize the physical keyboard map")
            try:
                self.keymap_bytes = ctypes.string_at(serialized) + b"\0"
            finally:
                libc = ctypes.CDLL(None)
                libc.free.argtypes = [pointer]
                libc.free.restype = None
                libc.free(serialized)
        except BaseException:
            self.close()
            raise

    def update(self, code, state):
        pressed = state == PRESSED
        if pressed == (code in self.down):
            return
        if pressed:
            self.down.add(code)
        else:
            self.down.discard(code)
        self.lib.xkb_state_update_key(self.state, code + 8, int(pressed))

    def masks(self):
        return (*(self.lib.xkb_state_serialize_mods(self.state, flag) for flag in (1, 2, 4)),
                self.lib.xkb_state_serialize_layout(self.state, 128))

    def close(self):
        for attr, unref in (("state", "xkb_state_unref"), ("keymap", "xkb_keymap_unref"),
                            ("context", "xkb_context_unref")):
            value = getattr(self, attr, None)
            if value:
                getattr(self.lib, unref)(value)
                setattr(self, attr, None)


class NativeInput:
    """No thread and no background authority; the caller owns the 20 ms loop."""

    def __init__(self, wayland_socket, hyprland_instance, window_address,
                 pause_file, *, parent_env=None, allow_shared=False):
        parent = dict(os.environ if parent_env is None else parent_env)
        if not wayland_socket or not hyprland_instance or not window_address:
            raise ValueError("Explicit socket, instance and target window are required")
        runtime = parent.get("XDG_RUNTIME_DIR", "")
        def socket_path(value):
            if not value:
                return None
            if not os.path.isabs(value) and not runtime:
                raise ValueError("Relative Wayland socket requires XDG_RUNTIME_DIR")
            return str(Path(value if os.path.isabs(value) else Path(runtime) / value).resolve())
        target = socket_path(wayland_socket)
        if not allow_shared and (
            target == socket_path(parent.get("WAYLAND_DISPLAY"))
            or hyprland_instance == parent.get("HYPRLAND_INSTANCE_SIGNATURE")
        ):
            raise ValueError("Refusing the captured parent desktop; select the nested session")
        self.env = dict(parent, WAYLAND_DISPLAY=target,
                        HYPRLAND_INSTANCE_SIGNATURE=hyprland_instance)
        self.env.pop("HYPRUSE_SEAT", None)
        if os.environ.get("HYPRUSE_SEAT"):
            raise ValueError("Unset HYPRUSE_SEAT for this separate-compositor adapter")
        self.window = window_address
        self.pause_file = Path(pause_file)
        self.vk = self.vp = self.xkb = None
        self.keyheld, self.buttonheld = set(), set()
        self.look = (0.0, 0.0)
        self.deadline = None
        self.last_tick = time.monotonic()
        self.last_check = float("-inf")
        self.closed = False
        try:
            self._check(force=True)
            self.xkb = XkbState(KEYMAP)
            self.vp = VirtualPointer(display=target)
            self.vk = VirtualKeyboard(display=target)
            self.vp._sock.settimeout(.2)
            self.vk._sock.settimeout(.2)
            seatname, _, version = next(g for g in self.vk._globals_cache if g[1] == "wl_seat")
            self.vk._seat = self.vk._new_id()
            self.vk._send(self.vk._registry, 0, struct.pack("<I", seatname)
                          + wl_string("wl_seat") + struct.pack("<II", min(version, 7), self.vk._seat))
            self.vk._roundtrip()
            self.keyboard = self.vk._new_keyboard()
            self.vk._upload_keymap(self.keyboard, self.xkb.keymap_bytes)
            self._send_modifiers()
            self.vk._roundtrip()
        except BaseException:
            self.close()
            raise

    def _hypr(self, *args):
        result = subprocess.run(["hyprctl", *args], env=self.env, capture_output=True,
                                text=True, timeout=.3, check=True)
        return result.stdout.strip()

    def _check(self, force=False):
        if self.closed:
            raise RuntimeError("NativeInput is closed")
        if self.pause_file.exists():
            raise RuntimeError("Emergency stop is active")
        now = time.monotonic()
        if force or now - self.last_check >= .1:
            active = json.loads(self._hypr("activewindow", "-j"))
            if active.get("address") != self.window:
                raise RuntimeError("Target window lost focus")
            self.last_check = now

    def _send_modifiers(self):
        self.vk._send(self.keyboard, VK_MODIFIERS, struct.pack("<IIII", *self.xkb.masks()))

    def _key(self, name, state):
        # Virtual keyboard key events do not carry the cumulative modifier mask.
        # Advertise the pre-key state, then commit the resulting state explicitly.
        self._send_modifiers()
        self.xkb.update(KEY_CODES[name], state)
        self.vk._send(self.keyboard, VK_KEY,
                      struct.pack("<III", _now_ms(), KEY_CODES[name], state))
        self._send_modifiers()
        self.vk._roundtrip()

    def _apply(self, keys, buttons):
        for name in sorted(self.keyheld - keys, key=lambda k: (k in MODIFIER_KEYS, k)):
            self._key(name, RELEASED)
            self.keyheld.discard(name)
        for name in sorted(self.buttonheld - buttons):
            self.vp.button(name, RELEASED)
            self.buttonheld.discard(name)
        for name in sorted(keys - self.keyheld, key=lambda k: (k not in MODIFIER_KEYS, k)):
            self.keyheld.add(name)
            self._key(name, PRESSED)
        for name in sorted(buttons - self.buttonheld):
            self.buttonheld.add(name)
            self.vp.button(name, PRESSED)

    def set_state(self, keys=(), buttons=(), look=(0, 0), *, lease_seconds=10):
        try:
            desired = {_key_name(k) for k in keys}
            buttons = set(buttons)
            if not buttons <= {"left", "right", "middle"}:
                raise ValueError("Unsupported mouse button")
            if len(look) != 2:
                raise ValueError("look must contain two velocities")
            velocity = tuple(_finite(x, "look velocity") for x in look)
            lease = _finite(lease_seconds, "lease")
            if not 0 < lease <= 10:
                raise ValueError("Lease must be greater than zero and at most 10 seconds")
            self._check(force=True)
            self._apply(desired, buttons)
            self.look = velocity
            self.deadline = time.monotonic() + lease
            self.last_tick = time.monotonic()
        except BaseException:
            self.close()
            raise

    def tick(self, dt=None):
        try:
            now = time.monotonic()
            elapsed = now - self.last_tick if dt is None else _finite(dt, "dt")
            self.last_tick = now
            if elapsed < 0:
                raise ValueError("dt must not be negative")
            self._check()
            if self.deadline is not None and now >= self.deadline:
                self.release()
                return {"status": "expired", "released": True}
            if self.deadline is not None and any(self.look):
                self.vp.move(self.look[0] * elapsed, self.look[1] * elapsed)
            return {"status": "active" if self.deadline is not None else "idle"}
        except BaseException:
            self.close()
            raise

    def tap(self, name):
        try:
            name = _key_name(name)
            self._check(force=True)
            restore = name in self.keyheld
            if restore:
                self._key(name, RELEASED)
            self.keyheld.add(name)
            self._key(name, PRESSED)
            time.sleep(.025)
            self._key(name, RELEASED)
            if restore:
                self._key(name, PRESSED)
            else:
                self.keyheld.discard(name)
        except BaseException:
            self.close()
            raise

    def click(self, x, y):
        try:
            x, y = _finite(x, "x"), _finite(y, "y")
            self._check(force=True)
            self.release()
            reply = self._hypr("dispatch", f"hl.dsp.cursor.move({{ x = {int(x)}, y = {int(y)} }})")
            if reply != "ok":
                raise RuntimeError(f"Cursor move failed: {reply}")
            time.sleep(.04)
            self._check(force=True)
            self.buttonheld.add("left")
            self.vp.button("left", PRESSED)
            time.sleep(.025)
            self.vp.button("left", RELEASED)
            self.buttonheld.discard("left")
        except BaseException:
            self.close()
            raise

    def screenshot(self):
        """Capture synchronously after release; use a separate worker for capture during motion."""
        try:
            self._check(force=True)
            self.release()
            script = "from hypruse import screenshot; import sys,json,base64; d,m=screenshot.capture(window=sys.argv[1]); print(json.dumps([base64.b64encode(d).decode(),m]))"
            result = subprocess.run([sys.executable, "-c", script, self.window], env=self.env,
                                    capture_output=True, text=True, timeout=10, check=True)
            encoded, metadata = json.loads(result.stdout)
            return base64.b64decode(encoded), metadata
        except BaseException:
            self.close()
            raise

    def release(self):
        self.look = (0.0, 0.0)
        self.deadline = None
        errors = []
        for name in list(self.keyheld):
            try:
                self._key(name, RELEASED)
            except BaseException as exc:
                errors.append(exc)
        for name in list(self.buttonheld):
            try:
                self.vp.button(name, RELEASED)
            except BaseException as exc:
                errors.append(exc)
        self.keyheld.clear()
        self.buttonheld.clear()
        if errors:
            self._close_devices()
            self.closed = True
            raise RuntimeError("Input release failed; connections closed") from errors[0]

    def _close_devices(self):
        if self.vk is not None and hasattr(self, "keyboard"):
            try:
                self.vk._send(self.keyboard, VK_MODIFIERS, struct.pack("<IIII", 0, 0, 0, 0))
                self.vk._roundtrip()
            except BaseException:
                pass
        for device in (self.vk, self.vp):
            if device is not None:
                try:
                    device.close()
                except BaseException:
                    try:
                        device._sock.close()
                    except BaseException:
                        pass
        if getattr(self, "xkb", None) is not None:
            self.xkb.close()
            self.xkb = None

    def close(self):
        if self.closed:
            return
        try:
            self.release()
        except BaseException:
            pass
        finally:
            self._close_devices()
            self.closed = True

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
