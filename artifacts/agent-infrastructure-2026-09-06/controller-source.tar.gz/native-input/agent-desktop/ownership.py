"""Cross-process writer coordination for one named desktop, not a security boundary."""
from contextlib import contextmanager
import fcntl
import hashlib
import hmac
import json
import os
from pathlib import Path
import secrets
import time


def _paths(state_path):
    directory = Path(state_path).parent
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    return directory / 'operation.lock', directory / 'owner.json'


@contextmanager
def _exclusive(state_path):
    lock_path, _ = _paths(state_path)
    with lock_path.open('a') as lock:
        lock_path.chmod(0o600)
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError('Workspace is busy executing another operation; retry after it finishes') from exc
        try:
            yield
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


def _read(state_path):
    path = Path(state_path).parent / 'owner.json'
    if not path.exists():
        return None
    record = json.loads(path.read_text())
    if record['expires_at'] <= time.time():
        return None
    return record


def _matches(record, token):
    return isinstance(token, str) and hmac.compare_digest(record['token_hash'], hashlib.sha256(token.encode()).hexdigest())


def _check(state_path, token, required):
    record = _read(state_path)
    if record is not None and not _matches(record, token):
        raise PermissionError(f"Workspace is leased to {record['owner']}; a matching lease token is required")
    if record is None and required:
        raise PermissionError('Claim this workspace before controlling it; lease missing or expired')
    return record


@contextmanager
def operation(state_path, lease_token=None, require_lease=False):
    """Hold the cross-process lock for the entire native/semantic action and cleanup."""
    with _exclusive(state_path):
        _check(state_path, lease_token, require_lease)
        yield


def ownership_status(state_path):
    record = _read(state_path)
    return {'claimed': bool(record), **({k: record[k] for k in ('owner', 'expires_at')} if record else {})}


def claim(state_path, owner, seconds=300, lease_token=None, validate=None):
    if not isinstance(owner, str) or not owner.strip() or len(owner) > 100 or any(ord(c) < 32 for c in owner):
        raise ValueError('Owner must be a nonempty label of at most 100 characters')
    if type(seconds) is not int or not 30 <= seconds <= 900:
        raise ValueError('Lease duration must be 30 to 900 seconds')
    with _exclusive(state_path):
        if validate is not None:
            validate()
        previous = _check(state_path, lease_token, False)
        if previous and previous['owner'] != owner:
            raise PermissionError('Release the existing lease before assigning another owner')
        token = lease_token if previous else secrets.token_urlsafe(32)
        record = {'owner': owner, 'expires_at': time.time() + seconds,
                  'token_hash': hashlib.sha256(token.encode()).hexdigest()}
        _, path = _paths(state_path)
        temp = path.with_suffix('.tmp')
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w') as output:
            json.dump(record, output)
        temp.replace(path)
        return {'owner': owner, 'expires_at': record['expires_at'], 'lease_token': token}


def release(state_path, lease_token):
    with _exclusive(state_path):
        _check(state_path, lease_token, True)
        (Path(state_path).parent / 'owner.json').unlink()
        return {'released': True}
