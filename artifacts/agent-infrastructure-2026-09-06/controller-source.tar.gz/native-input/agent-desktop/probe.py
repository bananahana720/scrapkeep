"""Read only the manifest's exact child browser PID through AT-SPI."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

from hypruse import a11y

MANIFEST = Path(os.environ.get('CODEX_AGENT_DESKTOP_STATE', str(Path.home()/'.local/state/codex-native-input/agent-desktop/session.json')))
ACCESSIBLE = 'org.a11y.atspi.Accessible'
ROOT = '/org/a11y/atspi/accessible/root'
DBUS = ('org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus')


def identity(expected_pid):
    manifest = json.loads(MANIFEST.read_text())
    browser = manifest['browser']
    if type(expected_pid) is not int or expected_pid <= 1 or browser['pid'] != expected_pid:
        raise ValueError('Expected PID does not match manifest child browser')
    fields = Path(f'/proc/{expected_pid}/stat').read_text().rsplit(')', 1)[1].split()
    if fields[0] in ('Z', 'X') or fields[19] != str(browser['start_ticks']):
        raise ValueError('Browser process identity is stale')
    if manifest['wayland_socket'] == manifest['parent_wayland_socket'] or manifest['hyprland_instance'] == manifest['parent_hyprland_instance']:
        raise ValueError('Manifest names the parent desktop')
    return str(browser['start_ticks'])


class BudgetBus(a11y.Bus):
    """Only discovery metadata or read methods; every app call checks exact owner PID."""
    def __init__(self, address, pid, deadline):
        super().__init__(address)
        self.pid, self.deadline = pid, deadline
        self.calls = 0

    def raw(self, verb, *args):
        left = self.deadline - time.monotonic()
        if left <= 0:
            raise TimeoutError('Accessibility observation budget reached')
        where = ['--address', self.address] if self.address else ['--user']
        proc = subprocess.run(['busctl', '--json=short', *where, verb, *args],
                              capture_output=True, text=True, timeout=min(.8, left), check=True)
        self.calls += 1
        return json.loads(proc.stdout)['data']

    def conn_pid(self, svc):
        return int(self.raw('call', *DBUS, 'GetConnectionUnixProcessID', 's', svc)[0])

    def authorize(self, svc):
        if self.conn_pid(svc) != self.pid:
            raise PermissionError('Accessible belongs to another PID; traversal stopped')

    def call(self, svc, path, interface, method, *args):
        registry = (svc == 'org.a11y.atspi.Registry' and path == ROOT and interface == ACCESSIBLE and method == 'GetChildren')
        if not registry:
            self.authorize(svc)
            accessible_read = interface == ACCESSIBLE and method in ('GetChildren', 'GetRole', 'GetRoleName', 'GetState', 'GetInterfaces')
            extent_read = interface == 'org.a11y.atspi.Component' and method == 'GetExtents' and args == ('u', '1')
            if not (accessible_read or extent_read):
                raise PermissionError('Unsupported accessibility method')
        return self.raw('call', svc, path, interface, method, *args)

    def prop(self, svc, path, interface, name):
        self.authorize(svc)
        if interface != ACCESSIBLE or name != 'Name':
            raise PermissionError('Unsupported accessibility property')
        return self.raw('get-property', svc, path, interface, name)


def read_ui(expected_pid, max_nodes=40):
    if not 1 <= max_nodes <= 100:
        raise ValueError('Node budget must be 1 to 100')
    ticks = identity(expected_pid)
    deadline = time.monotonic() + 8
    broker = BudgetBus('', expected_pid, deadline)
    address = broker.raw('call', 'org.a11y.Bus', '/org/a11y/bus', 'org.a11y.Bus', 'GetAddress')[0]
    bus = BudgetBus(address, expected_pid, deadline)
    # Empty title is mandatory: app_for_pid's title fallback must never run.
    app = a11y.app_for_pid(bus, expected_pid, title='')
    if app is None:
        return {'pid': expected_pid, 'start_ticks': ticks, 'found': False, 'nodes': []}
    bus.authorize(app[0])
    pending = [(app[0], app[1], 0)]
    nodes, visited = [], set()
    reason = None
    try:
        while pending and len(nodes) < max_nodes:
            svc, path, depth = pending.pop()
            if (svc, path) in visited:
                continue
            visited.add((svc, path))
            role = int(bus.call(svc, path, ACCESSIBLE, 'GetRole')[0])
            name = '[password field omitted]' if role == a11y.PASSWORD_ROLE else str(bus.prop(svc, path, ACCESSIBLE, 'Name'))[:300]
            nodes.append({'index': len(nodes), 'depth': depth, 'role': role, 'name': name})
            if role != a11y.PASSWORD_ROLE:
                kids = bus.call(svc, path, ACCESSIBLE, 'GetChildren')[0]
                pending.extend((cs, cp, depth + 1) for cs, cp in reversed(kids))
    except (TimeoutError, subprocess.TimeoutExpired):
        reason = 'time_budget'
    identity(expected_pid)
    return {'pid': expected_pid, 'start_ticks': ticks, 'found': True, 'scope': 'exact_browser_pid',
            'nodes': nodes, 'truncated': bool(pending), 'reason': reason or ('node_budget' if pending else None),
            'bus_calls': bus.calls}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--pid', type=int, required=True)
    parser.add_argument('--max-nodes', type=int, default=40)
    args = parser.parse_args()
    try:
        print(json.dumps(read_ui(args.pid, args.max_nodes), indent=2))
    except Exception as exc:
        print(json.dumps({'status': 'blocked', 'pid': args.pid, 'reason': str(exc)}))
        raise SystemExit(1)
