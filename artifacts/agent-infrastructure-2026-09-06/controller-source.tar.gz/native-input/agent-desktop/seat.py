#!/usr/bin/env python3
"""Manage named Hyprland desktops with independent browser profiles and inputs."""

import argparse
import json
import os
from pathlib import Path
import re
import secrets
import signal
import stat
import subprocess
import tempfile
import time

from ownership import operation


STATE_ROOT = Path.home() / '.local/state/codex-native-input/agent-desktop'
WORK_ROOT = Path.home() / '.local/share/codex-native-input/workspaces'
PAUSE = Path.home() / '.local/state/codex-native-input/paused'
NAME_PATTERN = re.compile(r'[a-z][a-z0-9_-]{0,31}\Z')


def validate_name(name):
    if not isinstance(name, str) or not NAME_PATTERN.fullmatch(name):
        raise ValueError('Workspace name must begin with a lowercase letter and contain at most 32 lowercase letters, digits, underscores, or hyphens')
    return name


def default_state_path(name):
    validate_name(name)
    return STATE_ROOT / 'session.json' if name == 'game' else STATE_ROOT / 'workspaces' / name / 'session.json'


WORKSPACE_NAME = validate_name(os.environ.get('CODEX_AGENT_WORKSPACE_NAME', 'game'))
STATE = Path(os.environ.get('CODEX_AGENT_DESKTOP_STATE', str(default_state_path(WORKSPACE_NAME)))).expanduser().absolute()


def work_directory(name):
    return WORK_ROOT / validate_name(name)


def _check_not_paused():
    if PAUSE.exists():
        raise RuntimeError('Emergency stop is active; codex-desktop resume first')


def hypr(env, *args):
    return subprocess.run(['hyprctl', *args], env=env, capture_output=True, text=True, timeout=2, check=True).stdout.strip()


def query(env, name):
    return json.loads(hypr(env, '-j', name))


def identity(pid):
    if type(pid) is not int or pid <= 1:
        raise ValueError('Invalid owned process PID')
    process = Path('/proc') / str(pid)
    contents = (process / 'stat').read_text()
    tail = contents[contents.rfind(')') + 2:].split()
    return {'pid': pid, 'state': tail[0], 'start_ticks': tail[19], 'process_group': int(tail[2])}


def owned(record):
    try:
        current = identity(record['pid'])
        return current['start_ticks'] == str(record['start_ticks']) and current['state'] != 'Z'
    except (OSError, KeyError, TypeError, ValueError, IndexError):
        return False


def _read_status(path, name):
    result = {'workspace_name': name, 'work_directory': str(work_directory(name)), 'state_path': str(path), 'running': False, 'paused': PAUSE.exists()}
    if not path.exists():
        return result
    record = json.loads(path.read_text())
    if record.get('workspace_name', 'game') != name:
        raise RuntimeError('Session manifest belongs to another workspace')
    result.update(record)
    result['running'] = owned(record.get('compositor', {})) and owned(record.get('browser', {}))
    if record.get('pid') != record.get('compositor', {}).get('pid'):
        result['running'] = False
    result['workspace_name'] = name
    result['work_directory'] = str(work_directory(name))
    result['state_path'] = str(path)
    return result


def status():
    return _read_status(STATE, WORKSPACE_NAME)


def list_workspaces():
    """List known directories and manifests without creating state or taking leases."""
    names = {'game', WORKSPACE_NAME}
    for root in (WORK_ROOT, STATE_ROOT / 'workspaces'):
        if root.exists():
            names.update(path.name for path in root.iterdir() if path.is_dir() and NAME_PATTERN.fullmatch(path.name))
    items = []
    for name in sorted(names):
        path = STATE if name == WORKSPACE_NAME else default_state_path(name)
        try:
            items.append(_read_status(path, name))
        except (OSError, ValueError, RuntimeError) as error:
            items.append({'workspace_name': name, 'work_directory': str(work_directory(name)), 'state_path': str(path), 'running': False, 'error': str(error)})
    return {'workspaces': items}


def _focus_snapshot(parent):
    window = query(parent, 'activewindow')
    if not window.get('address') or not window.get('pid'):
        return None
    try:
        process = identity(window['pid'])
    except (OSError, ValueError):
        return None
    return {'address': window['address'], 'pid': window['pid'], 'start_ticks': process['start_ticks']}


def _restore_parent_focus(parent, before, compositor_pid):
    """Undo focus stolen by our preview, without undoing a later human choice."""
    if not before or compositor_pid is None or not owned(before):
        return False
    try:
        active = query(parent, 'activewindow')
        if active.get('pid') != compositor_pid:
            return False
        previous = next((window for window in query(parent, 'clients') if window.get('address') == before['address'] and window.get('pid') == before['pid']), None)
        if previous is None:
            return False
        hypr(parent, 'dispatch', f'hl.dsp.focus({{window={json.dumps("address:" + before["address"])}}})')
        return True
    except (OSError, ValueError, subprocess.SubprocessError):
        return False


def _signal_owned(record, sig):
    """Only signal groups whose original session leader still has its saved identity."""
    if not owned(record):
        return False
    current = identity(record['pid'])
    if current['start_ticks'] != str(record['start_ticks']) or current['process_group'] != record['pid']:
        raise RuntimeError('Owned process is no longer its expected process group leader')
    try:
        os.killpg(record['pid'], sig)
    except ProcessLookupError:
        return False
    return True


def _stop_unlocked():
    session = status()
    records = [('application:' + app.get('application_id', str(app.get('pid'))), app) for app in reversed(session.get('applications', []))]
    records.extend((name, session[name]) for name in ('browser', 'compositor') if session.get(name))
    for _, record in records:
        _signal_owned(record, signal.SIGTERM)
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline and any(owned(record) for _, record in records):
        time.sleep(.05)
    remaining = [name for name, record in records if owned(record)]
    if remaining:
        raise RuntimeError('Still stopping: ' + ', '.join(remaining))
    STATE.unlink(missing_ok=True)
    return {'workspace_name': WORKSPACE_NAME, 'work_directory': str(work_directory(WORKSPACE_NAME)), 'state_path': str(STATE), 'running': False, 'stopped_owned_session': bool(session.get('compositor'))}


def _prepare_work_directory():
    directory = work_directory(WORKSPACE_NAME)
    if directory.is_symlink():
        raise RuntimeError('Workspace directory must not be a symlink')
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    directory.chmod(0o700)
    profile = directory / 'chromium'
    if profile.is_symlink():
        raise RuntimeError('Browser profile must not be a symlink')
    profile.mkdir(exist_ok=True, mode=0o700)
    profile.chmod(0o700)
    return directory, profile


def _child_environment(parent, instance, compositor_pid):
    if instance.get('pid') != compositor_pid or not instance.get('wl_socket') or not instance.get('instance'):
        raise RuntimeError('Nested compositor identity is incomplete')
    if instance['wl_socket'] == parent['WAYLAND_DISPLAY'] or instance['instance'] == parent['HYPRLAND_INSTANCE_SIGNATURE']:
        raise RuntimeError('Nested compositor must be distinct from the host desktop')
    socket_path = Path(instance['wl_socket'])
    if not socket_path.is_absolute():
        socket_path = Path(parent['XDG_RUNTIME_DIR']) / socket_path
    if not stat.S_ISSOCK(socket_path.stat().st_mode):
        raise RuntimeError('Nested Wayland socket is not available')
    env = dict(parent, WAYLAND_DISPLAY=instance['wl_socket'], HYPRLAND_INSTANCE_SIGNATURE=instance['instance'])
    env.pop('CODEX_AGENT_LEASE_TOKEN', None)
    return env


def _write_manifest(record):
    STATE.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = STATE.with_suffix('.tmp')
    with temporary.open('w') as output:
        os.fchmod(output.fileno(), 0o600)
        json.dump(record, output, indent=2)
    temporary.replace(STATE)


def _terminate_started(children):
    for child in reversed(children):
        if child.poll() is None:
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
    for child in reversed(children):
        try:
            child.wait(timeout=3)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            child.wait(timeout=2)


def _session_environment(session):
    if not session.get('running') or not owned(session.get('compositor', {})):
        raise RuntimeError('Workspace is not running')
    parent = dict(os.environ, WAYLAND_DISPLAY=session['parent_wayland_socket'], HYPRLAND_INSTANCE_SIGNATURE=session['parent_hyprland_instance'])
    matches = [item for item in query(parent, 'instances') if item.get('pid') == session['compositor']['pid'] and item.get('instance') == session['hyprland_instance'] and item.get('wl_socket') == session['wayland_socket']]
    if len(matches) != 1 or not owned(session['compositor']):
        raise RuntimeError('Workspace compositor identity changed')
    return _child_environment(parent, matches[0], session['compositor']['pid'])


def _run_unlocked(argv):
    _check_not_paused()
    if not argv or len(argv) > 128 or any(not isinstance(argument, str) or '\0' in argument for argument in argv):
        raise ValueError('run requires a command and at most 127 arguments without NUL bytes')
    session = status()
    env = _session_environment(session)
    applications = [app for app in session.get('applications', []) if owned(app)]
    if len(applications) >= 32:
        raise RuntimeError('Workspace already has 32 managed applications')
    folder = Path(session['runtime_directory'])
    directory, _ = _prepare_work_directory()
    application_id = secrets.token_hex(8)
    log_path = folder / f'application-{application_id}.log'
    child = None
    try:
        _check_not_paused()
        with log_path.open('wb') as log:
            child = subprocess.Popen(argv, env=dict(env, ACCESSIBILITY_ENABLED='1', NO_AT_BRIDGE='0'), cwd=directory, stdout=log, stderr=log, start_new_session=True)
        record = dict(identity(child.pid), application_id=application_id, command=Path(argv[0]).name, log_path=str(log_path), created_at=time.time())
        if not owned(record):
            raise RuntimeError(f'Application exited before it could be registered; see {log_path}')
        # Strip status-only annotations; the manifest remains the ownership record.
        manifest = {key: value for key, value in session.items() if key not in ('running', 'paused', 'state_path')}
        manifest['applications'] = applications + [record]
        _check_not_paused()
        _write_manifest(manifest)
        return dict(record, workspace_name=WORKSPACE_NAME, work_directory=str(directory))
    except BaseException:
        if child is not None:
            _terminate_started([child])
        raise


def _start_unlocked(url):
    _check_not_paused()
    previous = status()
    if previous.get('running'):
        return previous
    if previous.get('compositor') or previous.get('browser'):
        _stop_unlocked()
    parent = dict(os.environ)
    if not all(parent.get(name) for name in ('WAYLAND_DISPLAY', 'HYPRLAND_INSTANCE_SIGNATURE', 'XDG_RUNTIME_DIR')):
        raise RuntimeError('Launch from the normal Hyprland desktop environment')
    directory, profile = _prepare_work_directory()
    folder = Path(tempfile.mkdtemp(prefix=f'codex-agent-{WORKSPACE_NAME}-', dir=parent['XDG_RUNTIME_DIR']))
    config = folder / 'hyprland.lua'
    config.write_text('hl.monitor({ output="", mode="1280x900@60", position="0x0", scale=1 })\nhl.config({general={gaps_in=0,gaps_out=0,border_size=0},animations={enabled=false},misc={disable_hyprland_logo=true,disable_splash_rendering=true},input={follow_mouse=0}})\n')
    subprocess.run(['Hyprland', '--verify-config', '-c', str(config)], capture_output=True, timeout=5, check=True)
    before = _focus_snapshot(parent)
    children = []
    compositor_pid = None
    try:
        with (folder / 'compositor.log').open('wb') as log:
            compositor = subprocess.Popen(['Hyprland', '-c', str(config)], env=dict(parent, LIBSEAT_BACKEND='codex-nested-no-drm'), stdout=log, stderr=log, start_new_session=True, cwd=directory)
        compositor_pid = compositor.pid
        children.append(compositor)
        deadline = time.monotonic() + 12
        instance = None
        while time.monotonic() < deadline:
            _check_not_paused()
            if compositor.poll() is not None:
                raise RuntimeError(f'Nested compositor exited; see {folder}/compositor.log')
            matches = [item for item in query(parent, 'instances') if item.get('pid') == compositor.pid]
            if len(matches) > 1:
                raise RuntimeError('Ambiguous nested compositor identity')
            if matches:
                instance = matches[0]
                break
            time.sleep(.1)
        if instance is None:
            raise RuntimeError('Nested compositor startup timed out')
        env = _child_environment(parent, instance, compositor.pid)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            _check_not_paused()
            if query(env, 'monitors'):
                break
            time.sleep(.1)
        else:
            raise RuntimeError('No nested output')
        preview = next((window for window in query(parent, 'clients') if window.get('pid') == compositor.pid), None)
        if preview:
            target = json.dumps('address:' + preview['address'])
            if not preview.get('floating'):
                hypr(parent, 'dispatch', f'hl.dsp.window.float({{action="toggle",window={target}}})')
            hypr(parent, 'dispatch', f'hl.dsp.window.resize({{x=1280,y=900,relative=false,window={target}}})')
        with (folder / 'browser.log').open('wb') as log:
            browser = subprocess.Popen(['chromium', '--ozone-platform=wayland', '--no-first-run', '--disable-sync', '--disable-extensions', '--disable-default-apps', '--force-renderer-accessibility=complete', f'--user-data-dir={profile}', '--app=' + url, '--window-size=1280,900'], env=dict(env, ACCESSIBILITY_ENABLED='1', NO_AT_BRIDGE='0'), stdout=log, stderr=log, start_new_session=True, cwd=directory)
        children.append(browser)
        deadline = time.monotonic() + 12
        while time.monotonic() < deadline:
            _check_not_paused()
            if browser.poll() is not None:
                raise RuntimeError(f'Browser exited; see {folder}/browser.log')
            if any(window.get('pid') == browser.pid for window in query(env, 'clients')):
                break
            time.sleep(.1)
        else:
            raise RuntimeError('Browser window did not appear')
        record = {'workspace_name': WORKSPACE_NAME, 'work_directory': str(directory), 'profile_directory': str(profile), 'wayland_socket': instance['wl_socket'], 'hyprland_instance': instance['instance'], 'pid': compositor.pid, 'parent_wayland_socket': parent['WAYLAND_DISPLAY'], 'parent_hyprland_instance': parent['HYPRLAND_INSTANCE_SIGNATURE'], 'pause_file': str(PAUSE), 'runtime_directory': str(folder), 'url': url, 'created_at': time.time(), 'compositor': identity(compositor.pid), 'browser': identity(browser.pid)}
        _check_not_paused()
        _write_manifest(record)
        return dict(record, state_path=str(STATE), running=True)
    except BaseException:
        _terminate_started(children)
        raise
    finally:
        _restore_parent_focus(parent, before, compositor_pid)


def start(url='http://127.0.0.1:5173/orchard.html'):
    with operation(STATE, lease_token=os.environ.get('CODEX_AGENT_LEASE_TOKEN'), require_lease=False):
        return _start_unlocked(url)


def stop():
    with operation(STATE, lease_token=os.environ.get('CODEX_AGENT_LEASE_TOKEN'), require_lease=False):
        return _stop_unlocked()


def run(argv):
    with operation(STATE, lease_token=os.environ.get('CODEX_AGENT_LEASE_TOKEN'), require_lease=True):
        return _run_unlocked(argv)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['start', 'status', 'stop', 'list', 'run'])
    parser.add_argument('arguments', nargs=argparse.REMAINDER)
    arguments = parser.parse_args()
    rest = arguments.arguments
    if rest[:1] == ['--']:
        rest = rest[1:]
    if arguments.action == 'start' and len(rest) > 1:
        parser.error('start accepts one optional URL')
    if arguments.action in ('status', 'stop', 'list') and rest:
        parser.error(arguments.action + ' does not accept extra arguments')
    actions = {'start': lambda: start(rest[0] if rest else 'http://127.0.0.1:5173/orchard.html'), 'stop': stop, 'status': status, 'list': list_workspaces, 'run': lambda: run(rest)}
    print(json.dumps(actions[arguments.action](), indent=2))
