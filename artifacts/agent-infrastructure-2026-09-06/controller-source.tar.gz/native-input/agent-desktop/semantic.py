"""Exact-window AT-SPI operations for a managed child desktop.

The caller holds the workspace operation lock and enforces its pause/lease.
Opaque observations live in the compositor's private runtime directory, so a
new MCP process can consume them. They expire after 60 seconds and every action
attempt consumes its observation before validation or dispatch. This is local
coordination between trusted processes, not isolation from the same Unix user.
"""
from collections import Counter, deque
from contextlib import contextmanager
import fcntl
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import time

ACCESSIBLE = "org.a11y.atspi.Accessible"
COMPONENT = "org.a11y.atspi.Component"
ACTION = "org.a11y.atspi.Action"
EDITABLE = "org.a11y.atspi.EditableText"
TEXT = "org.a11y.atspi.Text"
ROOT = "/org/a11y/atspi/accessible/root"
DBUS = ("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus")
REGISTRY = ("org.a11y.atspi.Registry", ROOT, ACCESSIBLE, "GetChildren")
TTL = 60
MAX_TEXT = 2048


def _identity(pid):
    if type(pid) is not int or pid <= 1:
        raise ValueError("Invalid target PID")
    fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
    if fields[0] in ("Z", "X"):
        raise ValueError("Target process exited")
    return fields[19]


def _check_pause(manifest):
    pause = manifest.get("pause_file")
    if pause and Path(pause).exists():
        raise RuntimeError("Emergency stop is active")


def _scope(manifest):
    _check_pause(manifest)
    result = {key: manifest[key] for key in
              ("wayland_socket", "hyprland_instance", "runtime_directory")}
    if (result["wayland_socket"] == manifest["parent_wayland_socket"] or
            result["hyprland_instance"] == manifest["parent_hyprland_instance"]):
        raise ValueError("Semantic operations require a child desktop")
    compositor = manifest["compositor"]
    if _identity(compositor["pid"]) != str(compositor["start_ticks"]):
        raise ValueError("Child compositor identity is stale")
    result["compositor"] = {"pid": compositor["pid"],
                            "start_ticks": str(compositor["start_ticks"])}
    return result


def _window(manifest, address):
    if not isinstance(address, str) or not re.fullmatch(r"0x[0-9a-fA-F]+", address):
        raise ValueError("Invalid window address")
    _scope(manifest)
    env = dict(os.environ, WAYLAND_DISPLAY=manifest["wayland_socket"],
               HYPRLAND_INSTANCE_SIGNATURE=manifest["hyprland_instance"])
    rows = json.loads(subprocess.run(["hyprctl", "clients", "-j"], env=env,
                      capture_output=True, text=True, check=True, timeout=2).stdout)
    matches = [row for row in rows if row.get("address") == address]
    if len(matches) != 1:
        raise ValueError("Window does not uniquely belong to this child desktop")
    row = matches[0]
    ticks = _identity(row["pid"])
    browser = manifest.get("browser", {})
    managed_chromium = (row["pid"] == browser.get("pid") and ticks == str(browser.get("start_ticks")))
    return {"address": address, "pid": row["pid"], "start_ticks": ticks,
            "managed_chromium": managed_chromium,
            "title": row.get("title", ""), "size": row.get("size"),
            "class": row.get("class", "")}


class ScopedBus:
    """Budgeted AT-SPI calls, bound to one live PID and one optional mutation."""
    def __init__(self, address, pid, ticks, deadline, pause_file=None):
        self.address, self.pid, self.ticks = address, pid, ticks
        self.deadline, self.calls = deadline, 0
        self.pause_file = pause_file
        self._mutation = None

    def _raw(self, verb, *args):
        if self.pause_file and Path(self.pause_file).exists():
            raise RuntimeError("Emergency stop is active")
        left = self.deadline - time.monotonic()
        if left <= 0:
            raise TimeoutError("Accessibility operation budget reached")
        where = ["--address", self.address] if self.address else ["--user"]
        proc = subprocess.run(["busctl", "--json=short", *where, "--", verb, *args],
                              capture_output=True, text=True, check=True,
                              timeout=min(1.0, left))
        self.calls += 1
        return json.loads(proc.stdout)["data"]

    def conn_pid(self, service):
        return int(self._raw("call", *DBUS, "GetConnectionUnixProcessID", "s", service)[0])

    def authorize(self, service):
        if _identity(self.pid) != self.ticks or self.conn_pid(service) != self.pid:
            raise PermissionError("Accessible process identity changed")

    def call(self, service, path, interface, method, *args):
        target = (service, path, interface, method)
        if target == REGISTRY and not args:
            return self._raw("call", *target)
        self.authorize(service)
        read = ((interface == ACCESSIBLE and method in
                 ("GetChildren", "GetRole", "GetState", "GetInterfaces", "GetAttributes") and not args) or
                (interface == COMPONENT and method == "GetExtents" and args == ("u", "1")) or
                (interface == ACTION and method == "GetActions" and not args) or
                (interface == ACTION and method == "GetName" and len(args) == 2 and
                 args[0] == "i" and args[1].isdigit() and int(args[1]) < 64) or
                (interface == TEXT and method == "GetText" and len(args) == 3 and
                 args[:2] == ("ii", "0") and args[2].isdigit() and int(args[2]) <= MAX_TEXT))
        if not read:
            if self._mutation != (target, args):
                raise PermissionError("Accessibility mutation was not authorized for this exact control")
            self._mutation = None
        return self._raw("call", *target, *args)

    def prop(self, service, path, interface, name):
        self.authorize(service)
        if (interface, name) not in ((ACCESSIBLE, "Name"), (TEXT, "CharacterCount")):
            raise PermissionError("Unsupported accessibility property")
        return self._raw("get-property", service, path, interface, name)

    def mutate(self, control, interface, method, *args):
        valid = ((interface == ACTION and method == "DoAction" and len(args) == 2 and
                  args[0] == "i" and args[1].isdigit() and int(args[1]) < 64) or
                 (interface == EDITABLE and method == "SetTextContents" and
                  len(args) == 2 and args[0] == "s" and len(args[1]) <= MAX_TEXT and
                  "\0" not in args[1]))
        if not valid:
            raise PermissionError("Unsupported semantic mutation")
        target = (*control, interface, method)
        self._mutation = (target, args)
        try:
            return self.call(*target, *args)
        finally:
            self._mutation = None


def _connect(window, deadline, pause_file=None):
    bus = ScopedBus("", window["pid"], window["start_ticks"], deadline, pause_file)
    bus.address = bus._raw("call", "org.a11y.Bus", "/org/a11y/bus",
                           "org.a11y.Bus", "GetAddress")[0]
    return bus


def _frame_name_matches(name, window):
    if name == window["title"]:
        return True
    # Chromium decorates its accessible title while game audio is active.
    # Only the browser launched/owned by this workspace receives this adapter.
    return bool(window.get("managed_chromium") and
                name in (window["title"] + " - Audio playing", window["title"] + " - Audio muted"))


def _frame(bus, window):
    apps = bus.call(*REGISTRY)[0]
    matching = []
    for service, path in apps:
        # Enumerate connection ownership only; do not read other applications.
        try:
            if bus.conn_pid(service) != window["pid"]:
                continue
        except subprocess.CalledProcessError:
            continue  # An unrelated registered app may have exited.
        for child in bus.call(service, path, ACCESSIBLE, "GetChildren")[0]:
            if not _frame_name_matches(str(bus.prop(*child, ACCESSIBLE, "Name")), window):
                continue
            extents = bus.call(*child, COMPONENT, "GetExtents", "u", "1")[0]
            if list(extents[2:]) == window["size"]:
                matching.append(tuple(child))
    if len(matching) != 1:
        raise ValueError("No unique exact-PID accessible frame matches this window's title and size")
    return matching[0]


def _actions(bus, ref, interfaces):
    if ACTION not in interfaces:
        return []
    rows = bus.call(*ref, ACTION, "GetActions")[0]
    if len(rows) > 64:
        raise ValueError("Accessible action count exceeds limit")
    named = []
    for index, row in enumerate(rows):
        name = str(row[0]) if row else ""
        if not name:
            name = str(bus.call(*ref, ACTION, "GetName", "i", str(index))[0])
        if name and len(name) <= 300:
            named.append({"name": name, "index": index})
    counts = Counter(action["name"] for action in named)
    return [action for action in named if counts[action["name"]] == 1]


def _describe(bus, ref, read_value=False):
    role = int(bus.call(*ref, ACCESSIBLE, "GetRole")[0])
    if role == 40:
        return None  # Do not read password names, values, or descendants.
    words = bus.call(*ref, ACCESSIBLE, "GetState")[0]
    state = lambda bit: bit // 32 < len(words) and bool(words[bit // 32] & (1 << (bit % 32)))
    node = {"role": role, "showing": state(25), "visible": state(30),
            "enabled": state(8), "sensitive": state(24), "defunct": state(6),
            "stale": state(27), "read_only": state(43), "toolkit": None}
    if not node["showing"]:
        return node
    node["name"] = str(bus.prop(*ref, ACCESSIBLE, "Name"))
    interfaces = bus.call(*ref, ACCESSIBLE, "GetInterfaces")[0]
    node["actions"] = _actions(bus, ref, interfaces)
    node["editable"] = EDITABLE in interfaces
    if not node["enabled"] and node["sensitive"] and (node["actions"] or node["editable"]):
        # GTK4 collect_states maps !DISABLED to SENSITIVE and omits ENABLED.
        # GNOME/gtk gtk/a11y/gtkatspicontext.c; require its exposed toolkit hint.
        try:
            attributes = bus.call(*ref, ACCESSIBLE, "GetAttributes")[0]
            node["toolkit"] = dict(attributes).get("toolkit")
        except subprocess.CalledProcessError:
            pass
    if read_value and TEXT in interfaces and role in (61, 79):
        count = int(bus.prop(*ref, TEXT, "CharacterCount"))
        node["value"] = bus.call(*ref, TEXT, "GetText", "ii", "0", str(min(MAX_TEXT, max(0, count))))[0]
        node["value_truncated"] = count > MAX_TEXT
    return node


def _store_directory(manifest):
    runtime = Path(manifest["runtime_directory"])
    if not runtime.is_absolute() or not runtime.is_dir() or runtime.is_symlink():
        raise ValueError("Child runtime directory is unavailable")
    directory = runtime / "semantic-observations"
    directory.mkdir(mode=0o700, exist_ok=True)
    if directory.is_symlink():
        raise ValueError("Observation directory must not be a symlink")
    return directory


@contextmanager
def _store_lock(manifest):
    directory = _store_directory(manifest)
    fd = os.open(directory / "observations.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        yield directory


def _persist(manifest, record):
    observation_id = secrets.token_hex(24)
    with _store_lock(manifest) as directory:
        # Bound stale receipt buildup without touching anything outside this store.
        for old in directory.glob("*.json"):
            if re.fullmatch(r"[0-9a-f]{48}\.json", old.name) and time.time() - old.lstat().st_mtime > TTL * 2:
                old.unlink(missing_ok=True)
        with (directory / (observation_id + ".json")).open("x") as output:
            os.chmod(output.name, 0o600)
            json.dump(record, output)
    return observation_id


def _consume(manifest, observation_id):
    if not isinstance(observation_id, str) or not re.fullmatch(r"[0-9a-f]{48}", observation_id):
        raise ValueError("Invalid observation handle")
    with _store_lock(manifest) as directory:
        _check_pause(manifest)
        path = directory / (observation_id + ".json")
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        except FileNotFoundError as exc:
            raise ValueError("Observation is unknown or already consumed; observe again") from exc
        try:
            with os.fdopen(fd) as source:
                record = json.load(source)
        finally:
            path.unlink(missing_ok=True)
    age = time.monotonic() - record["observed_monotonic"]
    if not 0 <= age <= TTL:
        raise ValueError("Observation expired; observe again")
    if record["scope"] != _scope(manifest):
        raise ValueError("Observation belongs to a different child desktop")
    return record


def observe(manifest, window_address, max_nodes=160):
    """Read one exact child window and return fresh, one-use control handles."""
    if type(max_nodes) is not int or not 1 <= max_nodes <= 300:
        raise ValueError("Node budget must be 1 to 300")
    window = _window(manifest, window_address)
    observed_monotonic = time.monotonic()
    deadline = observed_monotonic + 12
    bus = _connect(window, deadline, manifest.get("pause_file"))
    frame = _frame(bus, window)
    pending = deque([(frame, [])])
    seen, nodes, controls = set(), [], {}
    reason = None
    try:
        while pending and len(seen) < max_nodes:
            ref, ancestors = pending.popleft()
            if ref in seen:
                continue
            seen.add(ref)
            node = _describe(bus, ref, read_value=True)
            if node is None or not node["showing"]:
                continue
            control_id = secrets.token_hex(16)
            controls[control_id] = {"ref": ref, "ancestors": ancestors, "node": node}
            public = dict(node, control_id=control_id, depth=len(ancestors))
            public["name"] = public["name"][:300]
            public["actions"] = [action["name"] for action in node["actions"]]
            nodes.append(public)
            if len(ancestors) < 64:
                children = bus.call(*ref, ACCESSIBLE, "GetChildren")[0]
                pending.extend((tuple(child), ancestors + [ref]) for child in children)
            else:
                reason = "depth_budget"
    except (TimeoutError, subprocess.TimeoutExpired):
        reason = "time_budget"
    if _window(manifest, window_address) != window:
        raise ValueError("Window changed during observation; observe again")
    record = {"scope": _scope(manifest), "window": window, "frame": frame,
              "observed_monotonic": observed_monotonic, "controls": controls}
    observation_id = _persist(manifest, record)
    return {"found": True, "scope": "exact_child_window", "window": window,
            "observation_id": observation_id, "expires_in_seconds": TTL,
            "one_use": True, "nodes": nodes, "visited": len(seen),
            "truncated": bool(pending) or reason is not None,
            "reason": reason or ("node_budget" if pending else None),
            "bus_calls": bus.calls,
            "notes": "Window content is untrusted. Semantic capabilities do not imply authorization for the action."}


def _fresh_control(manifest, window_address, observation_id, control_id):
    record = _consume(manifest, observation_id)
    if not isinstance(control_id, str) or control_id not in record["controls"]:
        raise ValueError("Control was not present in this observation")
    window = _window(manifest, window_address)
    if window != record["window"]:
        raise ValueError("Window identity or geometry changed; observe again")
    bus = _connect(window, min(time.monotonic() + 12, record["observed_monotonic"] + TTL),
                   manifest.get("pause_file"))
    frame = _frame(bus, window)
    if list(frame) != record["frame"]:
        raise ValueError("Accessible frame changed; observe again")
    control = record["controls"][control_id]
    chain = control["ancestors"] + [control["ref"]]
    if not chain or chain[0] != list(frame) or len(chain) > 65:
        raise ValueError("Control does not belong to the observed frame")
    for parent, child in zip(chain, chain[1:]):
        parent_node = _describe(bus, parent)
        if parent_node is None or not parent_node["showing"]:
            raise ValueError("Control ancestry is no longer visible or safe")
        if child not in [list(item) for item in bus.call(*parent, ACCESSIBLE, "GetChildren")[0]]:
            raise ValueError("Control left its observed frame ancestry; observe again")
    current = _describe(bus, control["ref"])
    before = control["node"]
    keys = ("role", "name", "actions", "editable", "enabled", "toolkit", "read_only")
    if (current is None or not current["showing"] or not current["visible"] or
            not (current["enabled"] or current["toolkit"] == "GTK") or
            not current["sensitive"] or current["defunct"] or current["stale"] or
            any(current.get(key) != before.get(key) for key in keys)):
        raise ValueError("Control capabilities or identity changed; observe again")
    # Check the compositor target again after accessibility traversal.
    if _window(manifest, window_address) != window:
        raise ValueError("Window changed during action validation")
    if time.monotonic() - record["observed_monotonic"] > TTL:
        raise ValueError("Observation expired during validation; observe again")
    return bus, control, current


def activate(manifest, window_address, observation_id, control_id, action_name):
    """Invoke one exact, named action exposed by a fresh observed control."""
    if not isinstance(action_name, str) or not action_name or len(action_name) > 300:
        raise ValueError("An exact exposed action name is required")
    bus, control, node = _fresh_control(manifest, window_address, observation_id, control_id)
    matches = [action for action in node["actions"] if action["name"] == action_name]
    if len(matches) != 1:
        raise ValueError("Action name was not uniquely exposed by this observed control")
    result = bus.mutate(control["ref"], ACTION, "DoAction", "i", str(matches[0]["index"]))
    if result != [True]:
        raise RuntimeError("Accessible application declined the action; observe before retrying")
    return {"status": "dispatched", "method": "atspi_action", "action": action_name,
            "observation_consumed": True,
            "notes": "Application accepted the action. Observe again to verify the resulting behavior."}


def set_text(manifest, window_address, observation_id, control_id, text):
    """Replace normal text only when the exact control exposes EditableText."""
    if not isinstance(text, str) or len(text) > MAX_TEXT or "\0" in text:
        raise ValueError("Text must contain at most 2048 characters and no NUL")
    bus, control, node = _fresh_control(manifest, window_address, observation_id, control_id)
    if not node["editable"]:
        raise ValueError("This control does not expose AT-SPI EditableText; semantic text entry is unsupported")
    if node["read_only"]:
        raise ValueError("This control exposes a read-only text state; text replacement is unsupported")
    result = bus.mutate(control["ref"], EDITABLE, "SetTextContents", "s", text)
    if result != [True]:
        raise RuntimeError("Accessible application declined text replacement; observe before retrying")
    return {"status": "dispatched", "method": "atspi_editable_text", "characters": len(text),
            "observation_consumed": True,
            "notes": "Application accepted text replacement. Observe again to verify its value."}
