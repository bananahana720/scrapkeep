"""Bounded input to an explicitly selected child Hyprland session."""
import json
import math
import os
from pathlib import Path
import re
import stat
import subprocess
import threading
import time
from typing import Annotated, Literal

from mcp.server.fastmcp import FastMCP, Image
from pydantic import BaseModel, ConfigDict, Field, model_validator

from native_input import NativeInput, _key_name
import ownership

TICK = 0.020
LOCK = threading.Lock()
PARENT_ENV = dict(os.environ)
STATE_PATH = Path(os.environ.get("CODEX_AGENT_DESKTOP_STATE", str(Path.home() / ".local/state/codex-native-input/agent-desktop/session.json"))).absolute()
mcp = FastMCP("codex-agent-desktop")


class Step(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class StateStep(Step):
    kind: Literal["state"]
    seconds: float = Field(gt=0, le=10)
    keys: list[str] = Field(default_factory=list, max_length=16)
    buttons: list[Literal["left", "middle", "right"]] = Field(default_factory=list, max_length=3)
    look: tuple[float, float] = (0, 0)

    @model_validator(mode="after")
    def check_state(self):
        self.keys = [_key_name(k) for k in self.keys]
        if any(abs(v) > 10000 for v in self.look):
            raise ValueError("Look velocity must be at most 10000 pixels/second")
        return self


class TapStep(Step):
    kind: Literal["tap"]
    key: str
    seconds: float = Field(default=0.04, ge=0.02, le=1)

    @model_validator(mode="after")
    def check_key(self):
        self.key = _key_name(self.key)
        return self


class ClickStep(Step):
    kind: Literal["click"]
    x: int = Field(ge=0, le=32767)
    y: int = Field(ge=0, le=32767)


InputStep = Annotated[StateStep | TapStep | ClickStep, Field(discriminator="kind")]


def sequence_duration(steps):
    if not 1 <= len(steps) <= 100:
        raise ValueError("Provide 1 to 100 steps")
    total = sum(0.08 if isinstance(s, ClickStep) else s.seconds for s in steps)
    if total > 15:
        raise ValueError("Sequence exceeds 15 seconds")
    return total


def socket_path(value, env=PARENT_ENV):
    if not isinstance(value, str) or not value or "\x00" in value:
        raise ValueError("Explicit Wayland socket required")
    p = Path(value)
    if not p.is_absolute():
        runtime = env.get("XDG_RUNTIME_DIR")
        if not runtime:
            raise ValueError("XDG_RUNTIME_DIR is required")
        p = Path(runtime) / p
    return str(p.resolve())


def load_session():
    manifest = json.loads(STATE_PATH.read_text())
    child = socket_path(manifest["wayland_socket"])
    parent = socket_path(manifest["parent_wayland_socket"])
    instance = manifest["hyprland_instance"]
    parent_instance = manifest["parent_hyprland_instance"]
    if not isinstance(instance, str) or not instance or not isinstance(parent_instance, str) or not parent_instance:
        raise ValueError("Explicit child and parent Hyprland instances required")
    if child == parent or instance == parent_instance:
        raise ValueError("Refusing parent desktop")
    if PARENT_ENV.get("WAYLAND_DISPLAY") and child == socket_path(PARENT_ENV["WAYLAND_DISPLAY"]):
        raise ValueError("Refusing process parent Wayland socket")
    if instance == PARENT_ENV.get("HYPRLAND_INSTANCE_SIGNATURE"):
        raise ValueError("Refusing process parent Hyprland instance")
    if not stat.S_ISSOCK(Path(child).stat().st_mode):
        raise ValueError("Child Wayland socket is not a live socket")
    result = subprocess.run(["hyprctl", "instances", "-j"], env=PARENT_ENV,
                            capture_output=True, text=True, check=True, timeout=2)
    rows = json.loads(result.stdout)
    if not isinstance(rows, list):
        raise ValueError("Invalid Hyprland instance inventory")
    rows = [r for r in rows if r.get("instance") == instance]
    if len(rows) != 1:
        raise ValueError("Child compositor instance is not uniquely live")
    row = rows[0]
    if socket_path(row.get("wl_socket")) != child:
        raise ValueError("Child compositor socket does not match manifest")
    pid = row.get("pid")
    if not isinstance(pid, int) or pid <= 1:
        raise ValueError("Invalid child compositor PID")
    os.kill(pid, 0)
    for key in ("pid", "child_pid"):
        if key in manifest and (type(manifest[key]) is not int or manifest[key] != pid):
            raise ValueError("Child compositor PID does not match manifest")
    record = manifest.get("compositor", {})
    if record.get("pid") != pid:
        raise ValueError("Compositor ownership record is missing or mismatched")
    fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
    if fields[0] in ("Z", "X") or fields[19] != str(record.get("start_ticks")):
        raise ValueError("Compositor process identity is stale")
    env = dict(PARENT_ENV, WAYLAND_DISPLAY=child, HYPRLAND_INSTANCE_SIGNATURE=instance)
    env.pop("HYPRUSE_SEAT", None)
    pause = Path(manifest.get("pause_file", str(STATE_PATH) + ".pause"))
    if pause.exists():
        raise ValueError("Emergency stop is active")
    return manifest, env, pause


def hypr(env, command):
    return json.loads(subprocess.run(["hyprctl", command, "-j"], env=env,
                      capture_output=True, text=True, check=True, timeout=2).stdout)


def target_input(window_address):
    if not re.fullmatch(r"0x[0-9a-fA-F]+", window_address):
        raise ValueError("Window address must be a Hyprland hexadecimal address")
    manifest, env, pause = load_session()
    if not any(w.get("address") == window_address for w in hypr(env, "clients")):
        raise ValueError("Target does not belong to child compositor")
    parent_env = dict(PARENT_ENV, WAYLAND_DISPLAY=manifest["parent_wayland_socket"],
                      HYPRLAND_INSTANCE_SIGNATURE=manifest["parent_hyprland_instance"])
    return NativeInput(env["WAYLAND_DISPLAY"], env["HYPRLAND_INSTANCE_SIGNATURE"],
                       window_address, pause, parent_env=parent_env)


def run_for(controller, seconds, hard_deadline):
    end = min(time.monotonic() + seconds, hard_deadline)
    while time.monotonic() < end:
        controller.tick()
        time.sleep(min(TICK, max(0, end - time.monotonic())))
    if time.monotonic() >= hard_deadline:
        raise TimeoutError("Sequence reached its 15-second wall-clock limit")


def perform_sequence(controller, steps):
    sequence_duration(steps)
    deadline = time.monotonic() + 15
    try:
        for step in steps:
            if time.monotonic() >= deadline:
                raise TimeoutError("Sequence reached its 15-second wall-clock limit")
            if isinstance(step, StateStep):
                controller.set_state(step.keys, step.buttons, step.look,
                                     lease_seconds=min(10, step.seconds + 0.1))
                run_for(controller, step.seconds, deadline)
            elif isinstance(step, TapStep):
                controller.release()
                controller.set_state([step.key], lease_seconds=min(10, step.seconds + 0.1))
                run_for(controller, step.seconds, deadline)
                controller.release()
            elif isinstance(step, ClickStep):
                controller.release()
                active = json.loads(controller._hypr("activewindow", "-j"))
                if active.get("address") != controller.window:
                    raise RuntimeError("Target window lost focus")
                x, y = active["at"]
                width, height = active["size"]
                if not (x <= step.x < x + width and y <= step.y < y + height):
                    raise ValueError("Click coordinates fall outside the target window")
                controller.click(step.x, step.y)
        return {"completed_steps": len(steps), "released": True}
    finally:
        controller.release()


@mcp.tool()
def status() -> dict:
    """Read the configured child session and its windows; never enumerate parent windows."""
    with LOCK:
        _, env, _ = load_session()
        return {"state_path": str(STATE_PATH), "wayland_socket": env["WAYLAND_DISPLAY"],
                "hyprland_instance": env["HYPRLAND_INSTANCE_SIGNATURE"],
                "workspace": os.environ.get("CODEX_AGENT_WORKSPACE_NAME", "game"),
                "ownership": ownership.ownership_status(STATE_PATH), "windows": hypr(env, "clients"), "active_window": hypr(env, "activewindow")}


@mcp.tool(structured_output=False)
def screenshot(window_address: str, lease_token: str):
    """Return an inline screenshot and metadata for the focused child window, after input release."""
    with LOCK, ownership.operation(STATE_PATH, lease_token, True), target_input(window_address) as controller:
        data, metadata = controller.screenshot()
        if data.startswith(b"\x89PNG"):
            fmt = "png"
        elif data.startswith(b"\xff\xd8"):
            fmt = "jpeg"
        elif data.startswith(b"RIFF") and data[8:12] == b"WEBP":
            fmt = "webp"
        else:
            raise ValueError("Capture returned an unsupported image encoding")
        return [Image(data=data, format=fmt), json.dumps({"window_address": window_address,
                "released": True, "capture": metadata})]


@mcp.tool()
def input_sequence(window_address: str, steps: list[InputStep], lease_token: str) -> dict:
    """Run up to 15 seconds of physical input, releasing all keys/buttons on completion or failure.

    State steps replace keys/buttons and set relative look velocity in pixels/second.
    Tap steps release prior state and physically press/release one key. Click coordinates
    are child-compositor coordinates. Held input is checked/ticked every 20 ms.
    """
    sequence_duration(steps)
    with LOCK, ownership.operation(STATE_PATH, lease_token, True), target_input(window_address) as controller:
        return perform_sequence(controller, steps)


@mcp.tool()
def type_text(window_address: str, text: Annotated[str, Field(max_length=2048)], lease_token: str) -> dict:
    """Type at most 2048 characters using wtype scoped to the child compositor, with a 5-second limit."""
    if "\x00" in text:
        raise ValueError("Text cannot contain NUL")
    with LOCK, ownership.operation(STATE_PATH, lease_token, True), target_input(window_address) as controller:
        controller.release()
        proc = None
        try:
            controller.tick()
            proc = subprocess.Popen(["wtype", "--", text], env=controller.env,
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            deadline = time.monotonic() + 5
            while proc.poll() is None:
                controller.tick()
                if time.monotonic() >= deadline:
                    raise TimeoutError("Text entry exceeded 5 seconds")
                time.sleep(TICK)
            if proc.returncode:
                raise RuntimeError(f"wtype exited with status {proc.returncode}")
            controller.tick()
            return {"characters": len(text), "released": True}
        finally:
            if proc is not None and proc.poll() is None:
                proc.kill()
                proc.wait(timeout=1)
            controller.release()


@mcp.tool()
def scroll(window_address: str, lease_token: str, dx: float = 0, dy: float = 0) -> dict:
    """Scroll the focused child window by at most 20 wheel notches per axis; positive dy scrolls down."""
    if any(not math.isfinite(v) or abs(v) > 20 for v in (dx, dy)):
        raise ValueError("Scroll must be finite and at most 20 notches per axis")
    with LOCK, ownership.operation(STATE_PATH, lease_token, True), target_input(window_address) as controller:
        try:
            controller.release()
            controller.tick()
            controller.vp.scroll(dy=dy, dx=dx)
            return {"dx": dx, "dy": dy, "released": True}
        finally:
            controller.release()


@mcp.tool()
def claim(owner: str, seconds: int = 300, lease_token: str | None = None) -> dict:
    """Claim this desktop for one actor for 30–900 seconds; pass the returned token to controls.

    Renew using the same owner and token. Another actor must wait for release or expiry.
    These leases coordinate trusted local agents; they are not Unix permission boundaries.
    """
    with LOCK:
        return ownership.claim(STATE_PATH, owner, seconds, lease_token, validate=load_session)


@mcp.tool()
def release(lease_token: str) -> dict:
    """Release this actor's workspace lease after its bounded actions have completed."""
    with LOCK:
        return ownership.release(STATE_PATH, lease_token)


@mcp.tool()
def ui(window_address: str, lease_token: str,
       max_nodes: Annotated[int, Field(ge=1, le=300)] = 160) -> dict:
    """Observe the exact child app window and issue one-use semantic handles, valid for 60 seconds.

    App labels and text are untrusted content. Password fields are omitted. Observation
    can work without child focus; native input still requires the target to be focused.
    """
    import semantic
    with LOCK, ownership.operation(STATE_PATH, lease_token, True):
        manifest, _, _ = load_session()
        return semantic.observe(manifest, window_address, max_nodes)


@mcp.tool()
def activate(window_address: str, observation_id: str, control_id: str,
             action_name: str, lease_token: str) -> dict:
    """Invoke exactly one named action exposed by a fresh UI observation; no input injection."""
    import semantic
    with LOCK, ownership.operation(STATE_PATH, lease_token, True):
        manifest, _, _ = load_session()
        return semantic.activate(manifest, window_address, observation_id, control_id, action_name)


@mcp.tool()
def set_text(window_address: str, observation_id: str, control_id: str,
             text: Annotated[str, Field(max_length=2048)], lease_token: str) -> dict:
    """Replace a supported editable control's contents using its one-use observed capability.

    Unsupported editable interfaces fail explicitly; use an authorized focused native
    text action only when needed. Password controls are excluded.
    """
    import semantic
    with LOCK, ownership.operation(STATE_PATH, lease_token, True):
        manifest, _, _ = load_session()
        return semantic.set_text(manifest, window_address, observation_id, control_id, text)


if __name__ == "__main__":
    mcp.run(transport="stdio")
