import re
import string
import unittest
from pathlib import Path

from test_native_input import adapter
from native_input import KEY_CODES, ALIASES, _key_name


HEADER_NAMES = {
    "Escape": "ESC", "Minus": "MINUS", "Equal": "EQUAL",
    "Backspace": "BACKSPACE", "Tab": "TAB", "BracketLeft": "LEFTBRACE",
    "BracketRight": "RIGHTBRACE", "Enter": "ENTER", "ControlLeft": "LEFTCTRL",
    "Semicolon": "SEMICOLON", "Quote": "APOSTROPHE", "Backquote": "GRAVE",
    "ShiftLeft": "LEFTSHIFT", "Backslash": "BACKSLASH", "Comma": "COMMA",
    "Period": "DOT", "Slash": "SLASH", "ShiftRight": "RIGHTSHIFT",
    "AltLeft": "LEFTALT", "Space": "SPACE", "CapsLock": "CAPSLOCK",
    "NumLock": "NUMLOCK", "ScrollLock": "SCROLLLOCK", "ControlRight": "RIGHTCTRL",
    "PrintScreen": "SYSRQ", "AltRight": "RIGHTALT", "Home": "HOME",
    "ArrowUp": "UP", "PageUp": "PAGEUP", "ArrowLeft": "LEFT",
    "ArrowRight": "RIGHT", "End": "END", "ArrowDown": "DOWN",
    "PageDown": "PAGEDOWN", "Insert": "INSERT", "Delete": "DELETE",
    "Pause": "PAUSE", "MetaLeft": "LEFTMETA", "MetaRight": "RIGHTMETA",
    "ContextMenu": "COMPOSE",
}


class GeneralKeyTests(unittest.TestCase):
    def test_every_code_matches_installed_kernel_header(self):
        header = Path("/usr/include/linux/input-event-codes.h").read_text()
        linux = {name: int(value) for name, value in re.findall(
            r"^#define\s+KEY_(\w+)\s+(\d+)\s*$", header, re.M)}
        for dom, code in KEY_CODES.items():
            if dom.startswith("Key"):
                name = dom[3:]
            elif dom.startswith("Digit"):
                name = dom[5:]
            elif re.fullmatch(r"F\d+", dom):
                name = dom
            else:
                name = HEADER_NAMES[dom]
            with self.subTest(key=dom):
                self.assertEqual(code, linux[name])

    def test_requested_coverage_and_unique_positions(self):
        expected = {"Key" + c for c in string.ascii_uppercase}
        expected |= {"Digit" + c for c in string.digits}
        expected |= {f"F{i}" for i in range(1, 13)}
        expected |= set(HEADER_NAMES)
        self.assertEqual(set(KEY_CODES), expected)
        self.assertEqual(len(KEY_CODES), len(set(KEY_CODES.values())))

    def test_navigation_and_function_keys_are_not_keypad_positions(self):
        self.assertEqual([KEY_CODES[k] for k in ("Home", "ArrowUp", "Delete", "F10", "F11", "F12")],
                         [102, 103, 111, 68, 87, 88])

    def test_all_old_game_aliases_are_preserved(self):
        for alias, dom in {"esc": "Escape", "w": "KeyW", "a": "KeyA", "s": "KeyS",
                           "d": "KeyD", "q": "KeyQ", "e": "KeyE", "r": "KeyR",
                           "i": "KeyI", "space": "Space", "Shift_L": "ShiftLeft",
                           "Control_L": "ControlLeft"}.items():
            self.assertEqual(_key_name(alias), dom)
        self.assertEqual(_key_name("\\"), "Backslash")
        for target in ALIASES.values():
            self.assertIn(target, KEY_CODES)

    def test_control_shift_shortcut_presses_modifiers_first(self):
        obj = adapter()
        obj._apply({"ControlLeft", "ShiftLeft", "KeyK"}, set())
        self.assertEqual(obj.vk.events, [("ControlLeft", 1), ("ShiftLeft", 1), ("KeyK", 1)])
        obj.vk.events.clear()
        obj._apply(set(), set())
        self.assertEqual(obj.vk.events, [("KeyK", 0), ("ControlLeft", 0), ("ShiftLeft", 0)])


if __name__ == "__main__":
    unittest.main()
