import ctypes
import struct
import unittest

from test_native_input import adapter
from native_input import NativeInput, XkbState, KEYMAP, KEY_CODES, VK_KEY, VK_MODIFIERS


class Wire:
    def __init__(self):
        self.messages = []
        self.closed = False

    def _send(self, obj, opcode, data):
        self.messages.append((opcode, struct.unpack('<' + 'I' * (len(data) // 4), data)))

    def _roundtrip(self):
        pass

    def close(self):
        self.closed = True


class ModifierTests(unittest.TestCase):
    def setUp(self):
        self.xkb = XkbState(KEYMAP)

    def tearDown(self):
        self.xkb.close()

    def press(self, key):
        self.xkb.update(KEY_CODES[key], 1)

    def release(self, key):
        self.xkb.update(KEY_CODES[key], 0)

    def test_ctrl_shift_k_mask_survives_ordinary_key(self):
        self.press('ControlLeft')
        self.assertEqual(self.xkb.masks(), (4, 0, 0, 0))
        self.press('ShiftLeft')
        self.assertEqual(self.xkb.masks(), (5, 0, 0, 0))
        self.press('KeyK')
        self.assertEqual(self.xkb.masks(), (5, 0, 0, 0))
        self.release('KeyK')
        self.assertEqual(self.xkb.masks(), (5, 0, 0, 0))
        self.release('ControlLeft')
        self.assertEqual(self.xkb.masks(), (1, 0, 0, 0))
        self.release('ShiftLeft')
        self.assertEqual(self.xkb.masks(), (0, 0, 0, 0))

    def test_either_shift_keeps_aggregate_shift_held(self):
        self.press('ShiftLeft')
        self.press('ShiftRight')
        self.release('ShiftLeft')
        self.assertEqual(self.xkb.masks()[0], 1)
        self.release('ShiftRight')
        self.assertEqual(self.xkb.masks()[0], 0)

    def test_caps_lock_and_shift_affect_own_keymap_translation(self):
        read_char = self.xkb.lib.xkb_state_key_get_utf32
        read_char.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        read_char.restype = ctypes.c_uint32
        self.assertEqual(chr(read_char(self.xkb.state, KEY_CODES['KeyK'] + 8)), 'k')
        self.press('CapsLock')
        self.release('CapsLock')
        self.assertEqual(self.xkb.masks()[2], 2)
        self.assertEqual(chr(read_char(self.xkb.state, KEY_CODES['KeyK'] + 8)), 'K')
        self.press('ShiftLeft')
        self.assertEqual(chr(read_char(self.xkb.state, KEY_CODES['KeyK'] + 8)), 'k')
        self.release('ShiftLeft')
        self.press('CapsLock')
        self.release('CapsLock')
        self.assertEqual(self.xkb.masks()[2], 0)

    def test_uploaded_keymap_is_fully_compiled_and_nul_terminated(self):
        self.assertTrue(self.xkb.keymap_bytes.endswith(b'\0'))
        self.assertNotIn(b'include ', self.xkb.keymap_bytes)
        clone = XkbState(self.xkb.keymap_bytes)
        try:
            clone.update(KEY_CODES['ControlLeft'], 1)
            clone.update(KEY_CODES['ShiftLeft'], 1)
            self.assertEqual(clone.masks(), (5, 0, 0, 0))
        finally:
            clone.close()

    def test_real_key_method_wraps_each_event_with_aggregate_modifiers(self):
        obj = adapter()
        obj.xkb = self.xkb
        obj.vk = Wire()
        obj.keyboard = 99
        obj._key = NativeInput._key.__get__(obj)
        obj._apply({'ControlLeft', 'ShiftLeft', 'KeyK'}, set())
        messages = obj.vk.messages
        self.assertEqual([op for op, _ in messages], [VK_MODIFIERS, VK_KEY, VK_MODIFIERS] * 3)
        self.assertEqual(messages[0][1], (0, 0, 0, 0))
        self.assertEqual(messages[2][1], (4, 0, 0, 0))
        self.assertEqual(messages[3][1], (4, 0, 0, 0))
        self.assertEqual(messages[5][1], (5, 0, 0, 0))
        self.assertEqual(messages[6][1], (5, 0, 0, 0))
        self.assertEqual(messages[7][1][1:], (KEY_CODES['KeyK'], 1))
        self.assertEqual(messages[8][1], (5, 0, 0, 0))
        obj.release()
        self.assertEqual(self.xkb.masks(), (0, 0, 0, 0))
        self.assertEqual(obj.vk.messages[-1], (VK_MODIFIERS, (0, 0, 0, 0)))

    def test_close_sends_zero_modifiers_even_for_locked_caps(self):
        obj = adapter()
        obj.xkb = self.xkb
        obj.vk = Wire()
        obj.keyboard = 99
        self.press('CapsLock')
        self.release('CapsLock')
        obj.close()
        self.assertEqual(obj.vk.messages[-1], (VK_MODIFIERS, (0, 0, 0, 0)))
        self.assertTrue(obj.vk.closed and obj.vp.closed)
        self.assertIsNone(self.xkb.state)


if __name__ == '__main__':
    unittest.main()
