import sys
import unittest
from unittest.mock import patch
from pathlib import Path

sys.path.insert(0, "/home/andrew/.local/share/codex-native-input/hypruse/src")
from native_input import NativeInput, KEY_CODES


class FakeDevice:
    def __init__(self):
        self.events = []
        self.closed = False
        self.fail_release = False

    def button(self, name, state):
        self.events.append((name, state))
        if self.fail_release and state == 0:
            raise RuntimeError("button release timeout")

    def move(self, dx, dy):
        self.events.append((dx, dy))

    def close(self):
        self.closed = True


def adapter():
    obj = NativeInput.__new__(NativeInput)
    obj.vk, obj.vp = FakeDevice(), FakeDevice()
    obj.keyheld, obj.buttonheld = set(), set()
    obj.look = (0, 0)
    obj.deadline = None
    obj.last_tick = 0
    obj.last_check = 0
    obj.closed = False
    obj._check = lambda force=False: None
    obj._key = lambda name, state: obj.vk.events.append((name, state))
    return obj


class NativeInputTests(unittest.TestCase):
    def test_physical_codes(self):
        self.assertEqual([KEY_CODES[k] for k in ("KeyW", "KeyA", "Space", "ShiftLeft")], [17, 30, 57, 42])

    def test_held_tap_restores_actual_pressed_state(self):
        obj = adapter()
        obj.keyheld.add("KeyW")
        with patch("native_input.time.sleep"):
            obj.tap("w")
        self.assertEqual(obj.vk.events, [("KeyW", 0), ("KeyW", 1), ("KeyW", 0), ("KeyW", 1)])
        self.assertEqual(obj.keyheld, {"KeyW"})

    def test_continuous_motion_preserves_elapsed_time(self):
        obj = adapter()
        obj.look = (100, 0)
        obj.deadline = 10
        with patch("native_input.time.monotonic", return_value=1):
            for _ in range(50):
                obj.tick(.02)
        self.assertAlmostEqual(sum(x for x, _ in obj.vp.events), 100)

    def test_expiry_releases_without_key_tap(self):
        obj = adapter()
        obj.keyheld.add("KeyW")
        obj.buttonheld.add("left")
        obj.deadline = .5
        with patch("native_input.time.monotonic", return_value=1):
            self.assertEqual(obj.tick(.02)["status"], "expired")
        self.assertEqual(obj.vk.events, [("KeyW", 0)])
        self.assertEqual(obj.vp.events, [("left", 0)])
        self.assertFalse(obj.closed)

    def test_release_failure_attempts_every_release_and_closes_both(self):
        obj = adapter()
        obj.keyheld.update(("KeyW", "KeyA"))
        obj.buttonheld.add("left")
        def fail(name, state):
            obj.vk.events.append((name, state))
            raise RuntimeError("keyboard sync timeout")
        obj._key = fail
        with self.assertRaises(RuntimeError):
            obj.release()
        self.assertEqual(set(obj.vk.events), {("KeyW", 0), ("KeyA", 0)})
        self.assertEqual(obj.vp.events, [("left", 0)])
        self.assertTrue(obj.vk.closed and obj.vp.closed and obj.closed)

    def test_press_timeout_is_tracked_before_send(self):
        obj = adapter()
        def fail_press(name, state):
            obj.vk.events.append((name, state))
            if state == 1:
                raise RuntimeError("press accepted but sync timed out")
        obj._key = fail_press
        with self.assertRaises(RuntimeError):
            obj.set_state(["w"])
        self.assertEqual(obj.vk.events, [("KeyW", 1), ("KeyW", 0)])
        self.assertTrue(obj.closed)

    def test_focus_failure_closes_and_releases(self):
        obj = adapter()
        obj.keyheld.add("KeyW")
        def fail(force=False):
            raise RuntimeError("Target window lost focus")
        obj._check = fail
        with self.assertRaises(RuntimeError):
            obj.tick(.02)
        self.assertEqual(obj.vk.events, [("KeyW", 0)])
        self.assertTrue(obj.closed)

    def test_parent_target_refused_before_device_creation(self):
        parent = {"WAYLAND_DISPLAY": "wayland-1", "XDG_RUNTIME_DIR": "/tmp", "HYPRLAND_INSTANCE_SIGNATURE": "parent"}
        with patch("native_input.VirtualPointer") as pointer:
            with self.assertRaises(ValueError):
                NativeInput("wayland-1", "nested", "0x1", "/tmp/stop", parent_env=parent)
            with self.assertRaises(ValueError):
                NativeInput("wayland-2", "parent", "0x1", "/tmp/stop", parent_env=parent)
            pointer.assert_not_called()

    def test_nan_lease_closes_without_press(self):
        obj = adapter()
        with self.assertRaises(ValueError):
            obj.set_state(["w"], lease_seconds=float("nan"))
        self.assertEqual(obj.vk.events, [])
        self.assertTrue(obj.closed)


if __name__ == "__main__":
    unittest.main()
