import json
import multiprocessing
from pathlib import Path
import tempfile
import time
import unittest

import ownership


def contender(state, token, pipe):
    try:
        with ownership.operation(state, token, True):
            pipe.send('entered')
    except Exception as exc:
        pipe.send(str(exc))


class OwnershipTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.state = Path(self.temp.name) / 'one' / 'session.json'

    def test_token_required_even_for_same_owner_label(self):
        lease = ownership.claim(self.state, 'agent')
        with self.assertRaises(PermissionError):
            ownership.claim(self.state, 'agent')
        with self.assertRaises(PermissionError):
            with ownership.operation(self.state, require_lease=True):
                self.fail('must not enter')
        with ownership.operation(self.state, lease['lease_token'], True):
            pass

    def test_other_process_cannot_overlap_even_with_valid_token(self):
        lease = ownership.claim(self.state, 'agent')
        ctx = multiprocessing.get_context('spawn')
        parent, child = ctx.Pipe()
        with ownership.operation(self.state, lease['lease_token'], True):
            proc = ctx.Process(target=contender, args=(self.state, lease['lease_token'], child))
            proc.start()
            self.assertTrue(parent.poll(5))
            self.assertIn('busy', parent.recv())
            proc.join(5)
            self.assertEqual(proc.exitcode, 0)
        parent.close(); child.close()

    def test_different_workspaces_operate_independently(self):
        one = ownership.claim(self.state, 'agent-one')
        other = self.state.parent.parent / 'two' / 'session.json'
        two = ownership.claim(other, 'agent-two')
        with ownership.operation(self.state, one['lease_token'], True):
            with ownership.operation(other, two['lease_token'], True):
                pass

    def test_expired_owner_can_be_replaced_and_old_token_refused(self):
        old = ownership.claim(self.state, 'old')
        path = self.state.parent / 'owner.json'
        record = json.loads(path.read_text()); record['expires_at'] = time.time() - 1
        path.write_text(json.dumps(record))
        new = ownership.claim(self.state, 'new')
        self.assertNotEqual(old['lease_token'], new['lease_token'])
        with self.assertRaises(PermissionError):
            with ownership.operation(self.state, old['lease_token'], True):
                self.fail('expired owner entered')

    def test_renew_and_release(self):
        lease = ownership.claim(self.state, 'agent')
        renewed = ownership.claim(self.state, 'agent', 900, lease['lease_token'])
        self.assertEqual(lease['lease_token'], renewed['lease_token'])
        with self.assertRaises(PermissionError):
            ownership.release(self.state, 'wrong')
        ownership.release(self.state, lease['lease_token'])
        self.assertFalse(ownership.ownership_status(self.state)['claimed'])

    def test_unclaimed_lifecycle_allowed_actions_refused(self):
        with ownership.operation(self.state):
            pass
        with self.assertRaises(PermissionError):
            with ownership.operation(self.state, require_lease=True):
                self.fail('unclaimed action')


class ClaimLifecycleTests(unittest.TestCase):
    def test_live_validation_is_inside_lock_and_failure_commits_no_owner(self):
        with tempfile.TemporaryDirectory() as directory:
            state = Path(directory) / 'session.json'
            def validate():
                with self.assertRaisesRegex(RuntimeError, 'busy'):
                    with ownership.operation(state):
                        self.fail('claim validation ran outside the lock')
                raise FileNotFoundError('session stopped')
            with self.assertRaises(FileNotFoundError):
                ownership.claim(state, 'agent', validate=validate)
            self.assertFalse((state.parent / 'owner.json').exists())
