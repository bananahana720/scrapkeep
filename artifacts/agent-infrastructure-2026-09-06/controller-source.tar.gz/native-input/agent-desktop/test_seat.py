import contextlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


@contextlib.contextmanager
def unlocked(*args, **kwargs):
    yield


# Unit tests do not launch desktops or create home state. Production supplies
# ownership.py next to seat.py; its cross-process behavior is tested separately.
ownership_stub = types.ModuleType('ownership')
ownership_stub.operation = unlocked
with patch.dict(sys.modules, {'ownership': ownership_stub}):
    spec = importlib.util.spec_from_file_location('seat_under_test', Path(__file__).with_name('seat.py'))
    seat = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(seat)


class WorkspaceLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='codex-seat-test-')
        self.root = Path(self.temporary.name)
        self.patches = [
            patch.object(seat, 'STATE_ROOT', self.root / 'state'),
            patch.object(seat, 'WORK_ROOT', self.root / 'work'),
            patch.object(seat, 'PAUSE', self.root / 'paused'),
            patch.object(seat, 'WORKSPACE_NAME', 'game'),
            patch.object(seat, 'STATE', self.root / 'state/session.json'),
        ]
        for item in self.patches:
            item.start()

    def tearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.temporary.cleanup()

    def save(self, record):
        seat.STATE.parent.mkdir(parents=True, exist_ok=True)
        seat.STATE.write_text(json.dumps(record))

    def test_names_cannot_select_filesystem_paths(self):
        for name in ('../studio', '/tmp/studio', 'studio/other', '', '.', 'UPPER', 'x' * 33, 'x\n'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                seat.validate_name(name)
        self.assertEqual(seat.validate_name('studio-2_tools'), 'studio-2_tools')

    def test_named_workspaces_have_separate_state_and_profiles(self):
        self.assertEqual(seat.default_state_path('game'), self.root / 'state/session.json')
        self.assertEqual(seat.default_state_path('studio'), self.root / 'state/workspaces/studio/session.json')
        first, first_profile = seat._prepare_work_directory()
        with patch.object(seat, 'WORKSPACE_NAME', 'studio'):
            second, second_profile = seat._prepare_work_directory()
        self.assertNotEqual(first, second)
        self.assertNotEqual(first_profile, second_profile)
        self.assertEqual(first.stat().st_mode & 0o777, 0o700)
        self.assertEqual(second_profile.stat().st_mode & 0o777, 0o700)

    def test_environment_selects_workspace_and_explicit_state_path(self):
        custom = self.root / 'custom/session.json'
        with patch.dict(os.environ, {'CODEX_AGENT_WORKSPACE_NAME': 'studio', 'CODEX_AGENT_DESKTOP_STATE': str(custom)}), patch.dict(sys.modules, {'ownership': ownership_stub}):
            specification = importlib.util.spec_from_file_location('seat_selected', Path(__file__).with_name('seat.py'))
            selected = importlib.util.module_from_spec(specification)
            specification.loader.exec_module(selected)
        self.assertEqual(selected.WORKSPACE_NAME, 'studio')
        self.assertEqual(selected.STATE, custom)

    def test_status_and_list_do_not_create_files(self):
        self.assertFalse(seat.status()['running'])
        self.assertEqual(seat.list_workspaces()['workspaces'][0]['workspace_name'], 'game')
        self.assertEqual(list(self.root.iterdir()), [])

    def test_lists_stopped_workspace_from_persistent_work_area(self):
        (seat.WORK_ROOT / 'studio').mkdir(parents=True)
        states = seat.list_workspaces()['workspaces']
        self.assertEqual([item['workspace_name'] for item in states], ['game', 'studio'])
        self.assertTrue(all(not item['running'] for item in states))

    def test_live_legacy_game_manifest_is_supported(self):
        record = {'pid': 200, 'compositor': {'pid': 200, 'start_ticks': '1'}, 'browser': {'pid': 201, 'start_ticks': '2'}}
        self.save(record)
        with patch.object(seat, 'owned', return_value=True):
            self.assertTrue(seat.status()['running'])
            self.assertEqual(seat.status()['workspace_name'], 'game')

    def test_manifest_cannot_cross_workspace_identity(self):
        self.save({'workspace_name': 'studio'})
        with self.assertRaisesRegex(RuntimeError, 'another workspace'):
            seat.status()

    def test_compositor_alias_pid_mismatch_is_not_running(self):
        self.save({'pid': 300, 'compositor': {'pid': 200}, 'browser': {'pid': 201}})
        with patch.object(seat, 'owned', return_value=True):
            self.assertFalse(seat.status()['running'])

    def test_reused_pid_and_zombies_are_not_owned(self):
        record = {'pid': 200, 'start_ticks': 'original'}
        with patch.object(seat, 'identity', return_value={'pid': 200, 'start_ticks': 'new', 'state': 'S'}):
            self.assertFalse(seat.owned(record))
        with patch.object(seat, 'identity', return_value={'pid': 200, 'start_ticks': 'original', 'state': 'Z'}):
            self.assertFalse(seat.owned(record))

    def test_missing_process_is_not_owned(self):
        with patch.object(seat, 'identity', side_effect=ProcessLookupError):
            self.assertFalse(seat.owned({'pid': 200, 'start_ticks': '1'}))

    def test_identity_reads_own_process_start_time(self):
        found = seat.identity(os.getpid())
        self.assertEqual(found['pid'], os.getpid())
        self.assertTrue(found['start_ticks'].isdigit())
        self.assertGreater(found['process_group'], 0)

    def test_signal_requires_original_group_leader(self):
        record = {'pid': 200, 'start_ticks': 'original'}
        current = {'pid': 200, 'start_ticks': 'original', 'state': 'S', 'process_group': 300}
        with patch.object(seat, 'identity', return_value=current), patch.object(seat.os, 'killpg') as kill:
            with self.assertRaisesRegex(RuntimeError, 'group leader'):
                seat._signal_owned(record, signal.SIGTERM)
            kill.assert_not_called()

    def test_stop_does_not_signal_reused_pid(self):
        self.save({'pid': 200, 'compositor': {'pid': 200, 'start_ticks': 'original'}})
        with patch.object(seat, 'identity', return_value={'pid': 200, 'start_ticks': 'new', 'state': 'S'}), patch.object(seat.os, 'killpg') as kill:
            self.assertFalse(seat._stop_unlocked()['running'])
            kill.assert_not_called()
        self.assertFalse(seat.STATE.exists())

    def test_focus_restored_only_from_owned_preview(self):
        before = {'address': '0x100', 'pid': 10, 'start_ticks': '1'}
        def response(env, name):
            return {'pid': 20} if name == 'activewindow' else [{'address': '0x100', 'pid': 10}]
        with patch.object(seat, 'owned', return_value=True), patch.object(seat, 'query', side_effect=response), patch.object(seat, 'hypr') as dispatch:
            self.assertTrue(seat._restore_parent_focus({}, before, 20))
            dispatch.assert_called_once()

    def test_human_focus_change_is_preserved(self):
        before = {'address': '0x100', 'pid': 10, 'start_ticks': '1'}
        with patch.object(seat, 'owned', return_value=True), patch.object(seat, 'query', return_value={'pid': 30}), patch.object(seat, 'hypr') as dispatch:
            self.assertFalse(seat._restore_parent_focus({}, before, 20))
            dispatch.assert_not_called()

    def test_previous_window_pid_must_still_match(self):
        before = {'address': '0x100', 'pid': 10, 'start_ticks': '1'}
        def response(env, name):
            return {'pid': 20} if name == 'activewindow' else [{'address': '0x100', 'pid': 99}]
        with patch.object(seat, 'owned', return_value=True), patch.object(seat, 'query', side_effect=response), patch.object(seat, 'hypr') as dispatch:
            self.assertFalse(seat._restore_parent_focus({}, before, 20))
            dispatch.assert_not_called()

    def test_start_and_stop_share_operation_lock_and_lease_token(self):
        with patch.dict(os.environ, {'CODEX_AGENT_LEASE_TOKEN': 'owner-token'}), patch.object(seat, 'operation', return_value=contextlib.nullcontext()) as lock, patch.object(seat, '_start_unlocked', return_value={'running': True}):
            self.assertTrue(seat.start()['running'])
            lock.assert_called_once_with(seat.STATE, lease_token='owner-token', require_lease=False)
        with patch.dict(os.environ, {'CODEX_AGENT_LEASE_TOKEN': 'owner-token'}), patch.object(seat, 'operation', return_value=contextlib.nullcontext()) as lock, patch.object(seat, '_stop_unlocked', return_value={'running': False}):
            self.assertFalse(seat.stop()['running'])
            lock.assert_called_once_with(seat.STATE, lease_token='owner-token', require_lease=False)

    def test_pause_prevents_start_before_reusing_session(self):
        seat.PAUSE.touch()
        with patch.object(seat, 'status') as status, self.assertRaisesRegex(RuntimeError, 'Emergency stop'):
            seat._start_unlocked('about:blank')
        status.assert_not_called()

    def test_reject_symlink_workspace(self):
        destination = self.root / 'unrelated'
        destination.mkdir()
        seat.WORK_ROOT.mkdir()
        (seat.WORK_ROOT / 'game').symlink_to(destination, target_is_directory=True)
        with self.assertRaisesRegex(RuntimeError, 'symlink'):
            seat._prepare_work_directory()
        self.assertEqual(list(destination.iterdir()), [])

    def test_run_uses_child_environment_and_requires_owner_lease(self):
        with patch.dict(os.environ, {'CODEX_AGENT_LEASE_TOKEN': 'owner-token'}), patch.object(seat, 'operation', return_value=contextlib.nullcontext()) as lock, patch.object(seat, '_run_unlocked', return_value={'pid': 200}):
            self.assertEqual(seat.run(['test-app'])['pid'], 200)
            lock.assert_called_once_with(seat.STATE, lease_token='owner-token', require_lease=True)

    def test_session_environment_rechecks_exact_instance_and_process(self):
        session = {'running': True, 'compositor': {'pid': 200, 'start_ticks': '1'}, 'parent_wayland_socket': 'wayland-host', 'parent_hyprland_instance': 'host-instance', 'hyprland_instance': 'child-instance', 'wayland_socket': 'wayland-child'}
        instance = {'pid': 200, 'instance': 'child-instance', 'wl_socket': 'wayland-child'}
        with patch.object(seat, 'owned', return_value=True), patch.object(seat, 'query', return_value=[instance]), patch.object(seat, '_child_environment', return_value={'WAYLAND_DISPLAY': 'wayland-child'}) as child:
            self.assertEqual(seat._session_environment(session)['WAYLAND_DISPLAY'], 'wayland-child')
            self.assertEqual(child.call_args.args[0]['WAYLAND_DISPLAY'], 'wayland-host')
            self.assertEqual(child.call_args.args[2], 200)
        with patch.object(seat, 'owned', return_value=True), patch.object(seat, 'query', return_value=[dict(instance, pid=201)]):
            with self.assertRaisesRegex(RuntimeError, 'identity changed'):
                seat._session_environment(session)

    def test_run_records_argv_application_with_owned_working_directory(self):
        folder = self.root / 'runtime'
        folder.mkdir()
        session = {'running': True, 'runtime_directory': str(folder)}
        process = types.SimpleNamespace(pid=200)
        with patch.object(seat, 'status', return_value=session), patch.object(seat, '_session_environment', return_value={'WAYLAND_DISPLAY': 'wayland-child'}), patch.object(seat.subprocess, 'Popen', return_value=process) as popen, patch.object(seat, 'identity', return_value={'pid': 200, 'start_ticks': '1', 'state': 'S', 'process_group': 200}), patch.object(seat, 'owned', return_value=True):
            result = seat._run_unlocked(['/bin/test-app', '--flag', 'literal;argument'])
        self.assertEqual(popen.call_args.args[0], ['/bin/test-app', '--flag', 'literal;argument'])
        self.assertEqual(popen.call_args.kwargs['env']['WAYLAND_DISPLAY'], 'wayland-child')
        self.assertEqual(popen.call_args.kwargs['cwd'], seat.WORK_ROOT / 'game')
        self.assertTrue(popen.call_args.kwargs['start_new_session'])
        self.assertEqual(result['pid'], 200)
        manifest = json.loads(seat.STATE.read_text())
        self.assertEqual(manifest['applications'][0]['pid'], 200)
        self.assertNotIn('running', manifest)
        self.assertEqual(seat.STATE.stat().st_mode & 0o777, 0o600)

    def test_stop_includes_managed_applications_before_browser_and_compositor(self):
        self.save({'pid': 200, 'compositor': {'pid': 200, 'start_ticks': '1'}, 'browser': {'pid': 201, 'start_ticks': '2'}, 'applications': [{'pid': 202, 'start_ticks': '3', 'application_id': 'fixture'}]})
        with patch.object(seat, 'owned', return_value=False), patch.object(seat, '_signal_owned') as signal_owned:
            seat._stop_unlocked()
        self.assertEqual([call.args[0]['pid'] for call in signal_owned.call_args_list], [202, 201, 200])


if __name__ == '__main__':
    unittest.main()
