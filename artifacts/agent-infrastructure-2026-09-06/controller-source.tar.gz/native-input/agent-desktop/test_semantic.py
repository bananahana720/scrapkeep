"""Safety and lifecycle checks independent of a graphical desktop."""
import json
from pathlib import Path
import tempfile
import time
import subprocess
import sys
import unittest
from unittest.mock import patch

import semantic as sem

SERVICE = ":1.42"
FRAME = (SERVICE, "/frame")
BUTTON = (SERVICE, "/frame/button")
ENTRY = (SERVICE, "/frame/entry")
PASSWORD = (SERVICE, "/frame/password")
PASSWORD_CHILD = (SERVICE, "/frame/password/child")
WINDOW = {"address": "0xa123", "pid": 100, "start_ticks": "10",
          "title": "Test", "size": [300, 200], "class": "test"}
STATE = [(1 << 8) | (1 << 24) | (1 << 25) | (1 << 30), 0]


class FakeBus:
    def __init__(self):
        self.nodes = {
            FRAME: {"role": 23, "name": "Test", "children": [BUTTON, ENTRY, PASSWORD]},
            BUTTON: {"role": 43, "name": "Record click", "actions": [["", "", ""], ["", "", ""]],
                     "action_names": ["press", "showContextMenu"]},
            ENTRY: {"role": 79, "name": "Test text", "editable": True, "value": "before"},
            PASSWORD: {"role": 40, "name": "Secret", "children": [PASSWORD_CHILD]},
            PASSWORD_CHILD: {"role": 79, "name": "Password descendant", "value": "do not read"},
        }
        self.calls = 0
        self.mutations = []
        self.reads = []
        self.mutation_return = [True]

    def call(self, service, path, interface, method, *args):
        self.calls += 1
        ref = (service, path)
        self.reads.append((ref, method))
        node = self.nodes[ref]
        if method == "GetRole":
            return [node["role"]]
        if method == "GetState":
            return [node.get("state", STATE)]
        if method == "GetInterfaces":
            interfaces = [sem.ACCESSIBLE, sem.COMPONENT]
            if "actions" in node:
                interfaces.append(sem.ACTION)
            if "value" in node:
                interfaces.append(sem.TEXT)
            if node.get("editable"):
                interfaces.append(sem.EDITABLE)
            return [interfaces]
        if method == "GetChildren":
            return [node.get("children", [])]
        if method == "GetActions":
            return [node["actions"]]
        if method == "GetAttributes":
            return [node.get("attributes", {})]
        if method == "GetName":
            return [node["action_names"][int(args[1])]]
        if method == "GetText":
            return [node["value"][:int(args[2])]]
        raise AssertionError((ref, interface, method, args))

    def prop(self, service, path, interface, name):
        ref = (service, path)
        self.reads.append((ref, name))
        node = self.nodes[ref]
        if name == "Name":
            return node["name"]
        if name == "CharacterCount":
            return len(node["value"])
        raise AssertionError(name)

    def mutate(self, ref, interface, method, *args):
        self.mutations.append((tuple(ref), interface, method, args))
        return self.mutation_return


class SemanticTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.manifest = {"runtime_directory": self.tmp.name, "wayland_socket": "child",
                         "hyprland_instance": "child-instance", "parent_wayland_socket": "parent",
                         "parent_hyprland_instance": "parent-instance",
                         "compositor": {"pid": 200, "start_ticks": "10"}}
        self.bus = FakeBus()
        for replacement in (patch.object(sem, "_identity", return_value="10"),
                            patch.object(sem, "_window", return_value=dict(WINDOW)),
                            patch.object(sem, "_connect", return_value=self.bus),
                            patch.object(sem, "_frame", return_value=FRAME)):
            replacement.start()
            self.addCleanup(replacement.stop)

    def observed(self, name="Record click"):
        observation = sem.observe(self.manifest, WINDOW["address"])
        node = next(node for node in observation["nodes"] if node["name"] == name)
        return observation["observation_id"], node["control_id"]

    def activate(self, handles, action="press"):
        return sem.activate(self.manifest, WINDOW["address"], *handles, action)

    def test_chromium_individual_action_names_and_one_use(self):
        observation = sem.observe(self.manifest, WINDOW["address"])
        node = next(node for node in observation["nodes"] if node["name"] == "Record click")
        self.assertEqual(node["actions"], ["press", "showContextMenu"])
        handles = observation["observation_id"], node["control_id"]
        self.assertEqual(self.activate(handles)["status"], "dispatched")
        with self.assertRaisesRegex(ValueError, "already consumed"):
            self.activate(handles)
        self.assertEqual(len(self.bus.mutations), 1)

    def test_password_subtree_is_never_read(self):
        observation = sem.observe(self.manifest, WINDOW["address"])
        self.assertFalse(any(node["role"] == 40 for node in observation["nodes"]))
        self.assertEqual([method for ref, method in self.bus.reads if ref == PASSWORD], ["GetRole"])
        self.assertFalse(any(ref == PASSWORD_CHILD for ref, method in self.bus.reads))

    def test_editable_text_and_bounded_value(self):
        handles = self.observed("Test text")
        result = sem.set_text(self.manifest, WINDOW["address"], *handles, "after")
        self.assertEqual(result["characters"], 5)
        self.assertEqual(self.bus.mutations[-1], (ENTRY, sem.EDITABLE, "SetTextContents", ("s", "after")))

    def test_unsupported_editable_text_refuses(self):
        self.bus.nodes[ENTRY]["editable"] = False
        handles = self.observed("Test text")
        with self.assertRaisesRegex(ValueError, "unsupported"):
            sem.set_text(self.manifest, WINDOW["address"], *handles, "after")
        self.assertEqual(self.bus.mutations, [])

    def test_action_not_exposed_consumes_observation(self):
        handles = self.observed()
        with self.assertRaisesRegex(ValueError, "not uniquely exposed"):
            self.activate(handles, "arbitrary action")
        with self.assertRaisesRegex(ValueError, "already consumed"):
            self.activate(handles)
        self.assertEqual(self.bus.mutations, [])

    def test_tampered_control_handle(self):
        observation, _ = self.observed()
        with self.assertRaisesRegex(ValueError, "not present"):
            self.activate((observation, "0" * 32))
        self.assertEqual(self.bus.mutations, [])

    def test_path_as_observation_handle_refused(self):
        with self.assertRaisesRegex(ValueError, "Invalid observation"):
            self.activate(("../../receipt", "0" * 32))

    def test_expired_observation_refused(self):
        handles = self.observed()
        path = Path(self.tmp.name) / "semantic-observations" / (handles[0] + ".json")
        record = json.loads(path.read_text())
        record["observed_monotonic"] = time.monotonic() - 61
        path.write_text(json.dumps(record))
        with self.assertRaisesRegex(ValueError, "expired"):
            self.activate(handles)
        self.assertFalse(path.exists())
        self.assertEqual(self.bus.mutations, [])

    def test_changed_desktop_refused(self):
        handles = self.observed()
        self.manifest["wayland_socket"] = "another-child"
        with self.assertRaisesRegex(ValueError, "different child"):
            self.activate(handles)

    def test_changed_pid_identity_refused(self):
        handles = self.observed()
        with patch.object(sem, "_window", return_value=dict(WINDOW, start_ticks="11")):
            with self.assertRaisesRegex(ValueError, "identity"):
                self.activate(handles)

    def test_reparented_control_refused(self):
        handles = self.observed()
        self.bus.nodes[FRAME]["children"] = [ENTRY]
        with self.assertRaisesRegex(ValueError, "ancestry"):
            self.activate(handles)
        self.assertEqual(self.bus.mutations, [])

    def test_action_index_reordering_refused(self):
        handles = self.observed()
        self.bus.nodes[BUTTON]["action_names"].reverse()
        with self.assertRaisesRegex(ValueError, "capabilities"):
            self.activate(handles)

    def test_disabled_control_refused(self):
        handles = self.observed()
        self.bus.nodes[BUTTON]["state"] = [STATE[0] & ~(1 << 8), 0]
        with self.assertRaisesRegex(ValueError, "capabilities"):
            self.activate(handles)

    def test_gtk_sensitive_control_without_enabled_is_supported(self):
        self.bus.nodes[BUTTON]["state"] = [STATE[0] & ~(1 << 8), 0]
        self.bus.nodes[BUTTON]["attributes"] = {"toolkit": "GTK"}
        handles = self.observed()
        self.assertEqual(self.activate(handles)["status"], "dispatched")

    def test_gtk_insensitive_control_is_refused(self):
        self.bus.nodes[BUTTON]["state"] = [STATE[0] & ~(1 << 8), 0]
        self.bus.nodes[BUTTON]["attributes"] = {"toolkit": "GTK"}
        handles = self.observed()
        self.bus.nodes[BUTTON]["state"] = [STATE[0] & ~(1 << 8) & ~(1 << 24), 0]
        with self.assertRaisesRegex(ValueError, "capabilities"):
            self.activate(handles)

    def test_stale_or_defunct_control_refused(self):
        for bit in (6, 27):
            handles = self.observed()
            self.bus.nodes[BUTTON]["state"] = [STATE[0] | (1 << bit), 0]
            with self.assertRaisesRegex(ValueError, "capabilities"):
                self.activate(handles)
            self.bus.nodes[BUTTON]["state"] = STATE

    def test_read_only_text_interface_refused(self):
        self.bus.nodes[ENTRY]["state"] = [STATE[0], 1 << (43 - 32)]
        handles = self.observed("Test text")
        with self.assertRaisesRegex(ValueError, "read-only"):
            sem.set_text(self.manifest, WINDOW["address"], *handles, "after")
        self.assertEqual(self.bus.mutations, [])

    def test_false_action_result_is_failure_and_consumed(self):
        handles = self.observed()
        self.bus.mutation_return = [False]
        with self.assertRaisesRegex(RuntimeError, "declined"):
            self.activate(handles)
        with self.assertRaisesRegex(ValueError, "already consumed"):
            self.activate(handles)

    def test_unknown_dispatch_result_is_consumed(self):
        handles = self.observed()
        with patch.object(self.bus, "mutate", side_effect=TimeoutError):
            with self.assertRaises(TimeoutError):
                self.activate(handles)
        with self.assertRaisesRegex(ValueError, "already consumed"):
            self.activate(handles)

    def test_stop_before_consumption_keeps_action_unsent(self):
        self.manifest["pause_file"] = str(Path(self.tmp.name) / "paused")
        handles = self.observed()
        Path(self.manifest["pause_file"]).touch()
        with self.assertRaisesRegex(RuntimeError, "Emergency stop"):
            self.activate(handles)
        self.assertEqual(self.bus.mutations, [])

    def test_persistent_observation_consumed_once_across_processes(self):
        handles = self.observed()
        code = ("import json,sys; import semantic; semantic._identity=lambda pid:'10'; "
                "record=semantic._consume(json.loads(sys.argv[1]),sys.argv[2]); "
                "print(record['window']['address'])")
        args = [sys.executable, "-c", code, json.dumps(self.manifest), handles[0]]
        directory = Path(__file__).resolve().parent
        first = subprocess.Popen(args, cwd=directory, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        second = subprocess.Popen(args, cwd=directory, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        outcomes = [(proc.communicate(timeout=5), proc.wait()) for proc in (first, second)]
        self.assertEqual(sorted(code for _, code in outcomes), [0, 1])
        successful = next(output for (output, errors), code in outcomes if code == 0)
        self.assertEqual(successful.strip(), WINDOW["address"])

    def test_duplicate_or_unnamed_actions_never_offered(self):
        self.bus.nodes[BUTTON]["action_names"] = ["press", "press"]
        observation = sem.observe(self.manifest, WINDOW["address"])
        node = next(node for node in observation["nodes"] if node["name"] == "Record click")
        self.assertEqual(node["actions"], [])
        self.bus.nodes[BUTTON]["action_names"] = ["", ""]
        self.assertEqual(sem._actions(self.bus, BUTTON, [sem.ACTION]), [])


class BusBoundaryTests(unittest.TestCase):
    def bus(self):
        return sem.ScopedBus("test-bus", 100, "10", time.monotonic() + 1)

    def test_direct_mutation_cannot_bypass_boundary(self):
        bus = self.bus()
        with patch.object(bus, "authorize"), patch.object(bus, "_raw") as raw:
            with self.assertRaisesRegex(PermissionError, "not authorized"):
                bus.call(*BUTTON, sem.ACTION, "DoAction", "i", "0")
            raw.assert_not_called()

    def test_wrong_pid_is_rejected_before_read(self):
        bus = self.bus()
        with patch.object(sem, "_identity", return_value="10"), patch.object(bus, "conn_pid", return_value=101), patch.object(bus, "_raw") as raw:
            with self.assertRaisesRegex(PermissionError, "identity"):
                bus.call(*BUTTON, sem.ACCESSIBLE, "GetRole")
            raw.assert_not_called()

    def test_mutation_grant_cleared_after_uncertain_failure(self):
        bus = self.bus()
        with patch.object(bus, "authorize"), patch.object(bus, "_raw", side_effect=TimeoutError):
            with self.assertRaises(TimeoutError):
                bus.mutate(BUTTON, sem.ACTION, "DoAction", "i", "0")
        self.assertIsNone(bus._mutation)
        with patch.object(bus, "authorize"):
            with self.assertRaises(PermissionError):
                bus.call(*BUTTON, sem.ACTION, "DoAction", "i", "0")

    def test_stop_checked_immediately_before_bus_dispatch(self):
        with tempfile.TemporaryDirectory() as directory:
            pause = Path(directory) / "paused"
            bus = sem.ScopedBus("test-bus", 100, "10", time.monotonic() + 1, str(pause))
            pause.touch()
            with patch.object(bus, "authorize"), patch.object(subprocess, "run") as run:
                with self.assertRaisesRegex(RuntimeError, "Emergency stop"):
                    bus.mutate(BUTTON, sem.ACTION, "DoAction", "i", "0")
                run.assert_not_called()


if __name__ == "__main__":
    unittest.main()


class ChromiumFrameTitleTests(unittest.TestCase):
    def test_owned_browser_audio_title_is_recognized(self):
        window = {'title': 'Scrapkeep', 'managed_chromium': True}
        self.assertTrue(sem._frame_name_matches('Scrapkeep', window))
        self.assertTrue(sem._frame_name_matches('Scrapkeep - Audio playing', window))
        self.assertTrue(sem._frame_name_matches('Scrapkeep - Audio muted', window))

    def test_other_apps_and_arbitrary_suffixes_are_refused(self):
        self.assertFalse(sem._frame_name_matches('Scrapkeep - Audio playing', {'title': 'Scrapkeep'}))
        for name in ('Scrapkeep clone - Audio playing', 'Scrapkeep - anything', 'Other - Audio playing'):
            self.assertFalse(sem._frame_name_matches(name, {'title': 'Scrapkeep', 'managed_chromium': True}))

    def test_multiple_matching_frames_are_still_ambiguous(self):
        from unittest.mock import Mock
        bus = Mock()
        bus.conn_pid.return_value = 1
        bus.call.side_effect = [[[['svc', 'app']]], [[['svc', 'one'], ['svc', 'two']]], [[0, 0, 1280, 900]], [[0, 0, 1280, 900]]]
        bus.prop.side_effect = ['Scrapkeep', 'Scrapkeep - Audio playing']
        with self.assertRaisesRegex(ValueError, 'No unique'):
            sem._frame(bus, {'pid': 1, 'title': 'Scrapkeep', 'size': [1280, 900], 'managed_chromium': True})
