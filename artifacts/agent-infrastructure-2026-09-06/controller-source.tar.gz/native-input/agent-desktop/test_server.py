import asyncio
import base64
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from pydantic import ValidationError

import server


class FakeInput:
    def __init__(self, fail=False):
        self.events = []
        self.fail = fail

    def release(self):
        self.events.append("release")

    def set_state(self, *args, **kwargs):
        self.events.append("state")

    def tick(self):
        self.events.append("tick")
        if self.fail:
            raise RuntimeError("focus changed")

    def click(self, x, y):
        self.events.append("click")

    window = "0x123"

    def _hypr(self, *args):
        return json.dumps({"address": self.window, "at": [10, 20], "size": [100, 100]})


class ValidationTests(unittest.TestCase):
    def test_total_duration_rejected_before_input(self):
        steps = [server.StateStep(kind="state", seconds=8)] * 2
        fake = FakeInput()
        with self.assertRaises(ValueError):
            server.perform_sequence(fake, steps)
        self.assertEqual(fake.events, [])

    def test_nonfinite_and_unknown_keys_rejected(self):
        for kwargs in ({"look": (float("nan"), 0)}, {"keys": ["not-a-key"]}, {"look": (float("inf"), 0)}):
            with self.assertRaises(ValidationError):
                server.StateStep(kind="state", seconds=.1, **kwargs)

    def test_state_runs_ticks_and_releases(self):
        fake = FakeInput()
        result = server.perform_sequence(fake, [server.StateStep(kind="state", seconds=.025, keys=["w"])])
        self.assertTrue(result["released"])
        self.assertIn("tick", fake.events)
        self.assertEqual(fake.events[-1], "release")

    def test_failure_releases(self):
        fake = FakeInput(fail=True)
        with self.assertRaisesRegex(RuntimeError, "focus changed"):
            server.perform_sequence(fake, [server.TapStep(kind="tap", key="Space")])
        self.assertEqual(fake.events[-1], "release")

    def test_parent_rejected_before_inventory(self):
        manifest = {"wayland_socket": "/tmp/wayland-parent", "parent_wayland_socket": "/tmp/wayland-parent",
                    "hyprland_instance": "child", "parent_hyprland_instance": "parent"}
        with patch.object(Path, "read_text", return_value=json.dumps(manifest)), patch.object(server.subprocess, "run") as run:
            with self.assertRaisesRegex(ValueError, "parent desktop"):
                server.load_session()
            run.assert_not_called()

    def test_click_outside_window_rejected_and_released(self):
        fake = FakeInput()
        with self.assertRaisesRegex(ValueError, "outside"):
            server.perform_sequence(fake, [server.ClickStep(kind="click", x=200, y=100)])
        self.assertNotIn("click", fake.events)
        self.assertEqual(fake.events[-1], "release")


class OutputTests(unittest.IsolatedAsyncioTestCase):
    async def test_screenshot_returns_native_mcp_image_and_metadata(self):
        from contextlib import contextmanager

        @contextmanager
        def fake_target(address):
            class Capture:
                def screenshot(self):
                    return base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aK1sAAAAASUVORK5CYII="), {"fake": True}
            yield Capture()

        with patch.object(server, "target_input", fake_target), patch.object(server.ownership, "operation", lambda *a: __import__("contextlib").nullcontext()):
            content = await server.mcp.call_tool("screenshot", {"window_address": "0x123", "lease_token": "test-token"})
        self.assertEqual([block.type for block in content], ["image", "text"])
        self.assertEqual(content[0].mimeType, "image/png")
        self.assertTrue(json.loads(content[1].text)["released"])


async def check_mcp():
    parameters = StdioServerParameters(command=sys.executable, args=[str(Path(__file__).with_name("server.py"))])
    async with stdio_client(parameters) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            response = await session.list_tools()
            names = {tool.name for tool in response.tools}
            assert names == {"status", "screenshot", "input_sequence", "type_text", "scroll", "ui", "claim", "release", "activate", "set_text"}, names
            sequence = next(tool for tool in response.tools if tool.name == "input_sequence")
            assert "steps" in sequence.inputSchema["properties"]
            # Rejected before session lookup or creation of any native input object.
            rejected = await session.call_tool("input_sequence", {"window_address": "0x123", "lease_token": "test-token", "steps": [
                {"kind": "state", "seconds": 8}, {"kind": "state", "seconds": 8}]})
            assert rejected.isError, rejected
            assert "15 seconds" in str(rejected.content)
            print("MCP initialization, ten tool schemas and over-limit rejection passed")


if __name__ == "__main__":
    result = unittest.main(exit=False)
    if not result.result.wasSuccessful():
        raise SystemExit(1)
    asyncio.run(check_mcp())
