import json
from pathlib import Path
import stat
import unittest
from unittest.mock import patch
import server


class SessionIdentityTests(unittest.TestCase):
    def test_reused_compositor_pid_refused(self):
        manifest = {'wayland_socket': '/tmp/child.sock', 'parent_wayland_socket': '/tmp/parent.sock',
                    'hyprland_instance': 'child-test', 'parent_hyprland_instance': 'parent-test',
                    'pid': 8765, 'compositor': {'pid': 8765, 'start_ticks': '100'}}
        inventory = type('Result', (), {'stdout': json.dumps([{'instance': 'child-test', 'wl_socket': '/tmp/child.sock', 'pid': 8765}])})()
        def read(path, *args, **kwargs):
            if str(path) == '/proc/8765/stat':
                return '8765 (Hyprland) ' + ' '.join(['S'] + ['0'] * 18 + ['200'])
            return json.dumps(manifest)
        with patch.object(Path, 'read_text', read), patch.object(Path, 'resolve', lambda p: p), patch.object(Path, 'stat', return_value=type('Stat', (), {'st_mode': stat.S_IFSOCK})()), patch.object(server.subprocess, 'run', return_value=inventory), patch.object(server.os, 'kill'):
            with self.assertRaisesRegex(ValueError, 'identity is stale'):
                server.load_session()
