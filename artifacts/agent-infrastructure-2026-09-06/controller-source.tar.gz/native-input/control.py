#!/usr/bin/env python3
"""Local MCP client and user-operated stop/resume for native desktop control."""
import asyncio
import base64
import json
import os
from pathlib import Path
import signal
import sys

ROOT = Path(__file__).resolve().parent
STATE = Path.home() / '.local/state/codex-native-input'
SERVER = ROOT / 'native-server.py'

def stop():
    STATE.mkdir(parents=True, exist_ok=True)
    (STATE / 'paused').write_text('Paused by emergency stop. Run codex-desktop resume.\n')
    stopped=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            argv=(proc/'cmdline').read_bytes().split(b'\0')
            if str(SERVER).encode() in argv and proc.stat().st_uid == os.getuid():
                os.kill(int(proc.name), signal.SIGTERM)
                stopped.append(int(proc.name))
        except (OSError, ValueError):
            continue
    print(json.dumps({'paused':True,'stopped_pids':stopped}))

async def run(mode, data):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    params=StdioServerParameters(command=str(ROOT/'hypruse/.venv/bin/python'),args=[str(SERVER)],env=os.environ.copy())
    async with stdio_client(params) as (read,write):
        async with ClientSession(read,write) as client:
            await client.initialize()
            if mode=='list':
                result=await client.list_tools()
                print(result.model_dump_json())
                return
            calls=data if isinstance(data,list) else [data]
            for i,call in enumerate(calls):
                result=await client.call_tool(call['tool'],call.get('arguments',{}))
                obj=result.model_dump(mode='json')
                obj.pop('structuredContent', None)
                for block in obj.get('content',[]):
                    if block.get('type')=='image':
                        if 'image_path' in call:
                            target=Path(call['image_path']).expanduser().resolve()
                            target.parent.mkdir(parents=True,exist_ok=True)
                            target.write_bytes(base64.b64decode(block.pop('data')))
                            block['saved_path']=str(target)
                        else:
                            block['data']='[image omitted; pass image_path to save]'
                print(json.dumps({'tool':call['tool'],'result':obj}),flush=True)
                if result.isError:
                    raise SystemExit(1)

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'help'
    if mode=='stop':stop()
    elif mode=='resume':
        (STATE/'paused').unlink(missing_ok=True)
        print('Native desktop control resumed.')
    elif mode=='status':print(json.dumps({'paused':(STATE/'paused').exists(),'server':str(SERVER)}))
    elif mode=='list':asyncio.run(run(mode,None))
    elif mode=='call':
        data=json.loads(sys.argv[2]) if len(sys.argv)>2 else json.load(sys.stdin)
        asyncio.run(run(mode,data))
    else:print('Usage: codex-desktop list | call JSON | stop | resume | status\nFor call, JSON is {"tool":"desktop","arguments":{}} or a list. Input may also come from stdin. Screenshot calls accept image_path.')
