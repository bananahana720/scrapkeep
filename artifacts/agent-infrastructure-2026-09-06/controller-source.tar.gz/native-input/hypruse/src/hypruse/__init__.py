"""hypruse, computer use for Hyprland over MCP."""

__version__ = "0.10.0"
