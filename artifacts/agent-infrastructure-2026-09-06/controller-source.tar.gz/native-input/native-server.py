#!/usr/bin/env python3
"""Pinned native desktop MCP entry point; no package downloads at startup."""
import os
import sys
from pathlib import Path

STATE = Path.home() / '.local/state/codex-native-input'
STATE.mkdir(parents=True, exist_ok=True)
if (STATE / 'paused').exists():
    sys.exit('Native desktop control is paused. Run codex-desktop resume when ready.')
os.environ['HYPRUSE_CLIPBOARD'] = '0'
os.environ['HYPRUSE_AUTH_GUARD'] = 'strict'
os.environ['HYPRUSE_STRICT'] = '1'
os.environ['HYPRUSE_JOURNAL'] = str(STATE / 'actions.ndjson')
os.environ.setdefault('HYPRUSE_SCREENSHOT_MODE', 'image')
from hypruse import server
for name in ('launch', 'use_bind', 'binds', 'hypr', 'sequence'):
    server.mcp.remove_tool(name)
server.main()
