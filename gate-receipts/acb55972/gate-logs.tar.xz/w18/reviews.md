## Opus-medium reviews on trial merges onto a63d2cb6
- #173 94a0b1df: ACCEPT+NOTES (third hash still fails; dump opt-in; minor: null guard in dump mode, usage message in diff tool)
- #227 1b3e25d9: ACCEPT+NOTES conditional on the three asset tests passing on the merge (tests hash .gd sources; #204 touches only glb/py); minor: no provenance comment for the re-pin
- #230 1d200429: ACCEPT+NOTES (marker parses; 360 s is the hard ceiling)
- #223 ee44239f: FAIL. Windup test loosening breaks on stage (stage 29/29 PASS; merge FAIL 7 of 19); other 3 files OK.
- #224 3df69e99: ACCEPT+NOTES (minor scope: ending-page comic row hide).
- #222 6be83b85: REJECT. Class III monster gate vs ruling DECISIONS:178 (class V ordinary); hive 2x unmeasured.
- #225 2f2b9c3d: ACCEPT+NOTES (minor: rel path containment, dangling symlink copy; wave-specific default path).
- #226 d33e6034: REJECT. Base-red cache stickiness hides head reds.

## #281 c4b861e1 (independent, Opus 5.5 medium, static read of diff-281.patch + trial f281)
VERDICT ACCEPT+NOTES. Pack rows match alpha/park defs; paddle_ride fires once on boost break (swatter.gd:118, counter.gd:290-294, combat.gd:4033); no pin loosened (codex_coverage NEVER_SPAWNS removal required; director_credit 1118->1120 = 2 packs). Notes: entry text mentions jumping the paddle but only boost triggers; _has_press_shape control near-circular, walls caught only by lab WALL control; stale comment authored_nemesis_packs_test.gd:155; tools/matchup_lab.md:47 says plate_press removed (doc follow-up).

## #304 5019d775 (independent, Opus 5.5 medium, static read)
VERDICT ACCEPT+NOTES. Look-only: material/texture in park_terrain.gd make_render (:123-134) + ground_assets (:145-156); no height/collider/schedule change; single setup-time caller terrain.gd:163. Test can fail (texture paths, uv_scale tile metres, floor_metres). Notes: test does not assert auto_base/overlay texture swap; ART-MISTAKES row records a #289 mistake (out of scope, harmless).

## #290 head 4567be15 (scrapkeep-reviewer-medium, Opus 5.5 medium, static read)
ACCEPT+NOTES. `# smoke: solo timeout=300s (...)` parses in both runners (sketch-smoke.mjs:55,61, MARKER_LINES=5; sketch-fast imports isSolo/testTimeoutMs); solo runs after the pool (smoke :701-709, fast :217-218,:773-776); 300 s inside 180-360 s clamp (smoke :62,:78); same convention as park_world_scenery_test.gd:1. Note: fixes only the 180 s kill, not the load-sensitive threaded-build checks.
